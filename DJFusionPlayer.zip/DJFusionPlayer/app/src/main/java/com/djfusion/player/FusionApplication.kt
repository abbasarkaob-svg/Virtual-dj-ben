package com.djfusion.player

import android.app.Application
import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.room.Room
import com.djfusion.player.data.FusionDb
import com.djfusion.player.data.MediaRepository
import com.djfusion.player.data.SettingsStore
import com.djfusion.player.djengine.DjEngine
import com.djfusion.player.playback.PlayerManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

@UnstableApi
class AppContainer(app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val db: FusionDb = Room.databaseBuilder(app, FusionDb::class.java, "fusion.db")
        .fallbackToDestructiveMigration().build()
    val settings = SettingsStore(app)
    val repo = MediaRepository(app, db)
    val player = PlayerManager(app, repo, settings, scope)
    /** Les platines DJ ne sont créées qu'à la première ouverture du studio. */
    val dj by lazy { DjEngine(app, repo, settings, scope) }
}

@UnstableApi
class FusionApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        container.player.restore()
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
val Context.container: AppContainer
    get() = (applicationContext as FusionApplication).container
