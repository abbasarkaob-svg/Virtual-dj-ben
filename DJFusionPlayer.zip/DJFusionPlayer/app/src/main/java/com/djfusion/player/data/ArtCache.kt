package com.djfusion.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.LruCache

/** Cache mémoire LRU des pochettes (et miniatures vidéo). Chargement hors thread principal. */
object ArtCache {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8L / 1024L).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val missing = HashSet<String>()

    fun load(ctx: Context, uri: String, video: Boolean): Bitmap? {
        cache.get(uri)?.let { return it }
        synchronized(missing) { if (uri in missing) return null }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, Uri.parse(uri))
            val bmp: Bitmap? = if (video) {
                r.getFrameAtTime(1_000_000L)?.let { Bitmap.createScaledBitmap(it, 320, (320f * it.height / it.width).toInt().coerceAtLeast(1), true) }
            } else {
                r.embeddedPicture?.let { decode(it) }
            }
            if (bmp == null) synchronized(missing) { missing.add(uri) } else cache.put(uri, bmp)
            bmp
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var sample = 1
        while (o.outWidth / sample > 600) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2)
    }
}
