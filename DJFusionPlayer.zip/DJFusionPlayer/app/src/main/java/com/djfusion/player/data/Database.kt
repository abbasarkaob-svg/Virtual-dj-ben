package com.djfusion.player.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "tracks", indices = [Index(value = ["uri"], unique = true)])
data class TrackEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val durationMs: Long,
    val folder: String,
    val isVideo: Boolean,
    val favorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "playlist_items", primaryKeys = ["playlistId", "trackId"])
data class PlaylistItem(val playlistId: Long, val trackId: Long, val position: Int = 0)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val trackId: Long,
    val playedAt: Long
)

@Entity(tableName = "hot_cues", primaryKeys = ["trackId", "slot"])
data class HotCueEntity(val trackId: Long, val slot: Int, val positionMs: Long)

data class GenreCount(val genre: String, val count: Int)

@Dao
interface TrackDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(tracks: List<TrackEntity>)

    @Query("SELECT * FROM tracks WHERE isVideo = 0 ORDER BY title COLLATE NOCASE")
    fun songs(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE isVideo = 1 ORDER BY title COLLATE NOCASE")
    fun videos(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE favorite = 1 ORDER BY title COLLATE NOCASE")
    fun favorites(): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE title LIKE '%' || :q || '%' OR artist LIKE '%' || :q || '%' OR album LIKE '%' || :q || '%' ORDER BY title COLLATE NOCASE LIMIT 200")
    fun search(q: String): Flow<List<TrackEntity>>

    @Query("SELECT * FROM tracks WHERE id = :id")
    fun observe(id: Long): Flow<TrackEntity?>

    @Query("SELECT * FROM tracks WHERE id = :id")
    suspend fun byId(id: Long): TrackEntity?

    @Query("UPDATE tracks SET favorite = :fav WHERE id = :id")
    suspend fun setFavorite(id: Long, fav: Boolean)

    @Query("DELETE FROM tracks WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM tracks")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM tracks")
    fun count(): Flow<Int>

    @Query("SELECT genre, COUNT(*) AS count FROM tracks WHERE isVideo = 0 GROUP BY genre ORDER BY count DESC")
    fun genres(): Flow<List<GenreCount>>

    @Query("SELECT * FROM tracks WHERE isVideo = 0 AND genre = :genre ORDER BY title COLLATE NOCASE")
    fun byGenre(genre: String): Flow<List<TrackEntity>>

    @Query(
        "SELECT * FROM tracks WHERE isVideo = 0 AND id != :id AND " +
            "((genre = :genre AND genre != 'Inconnu') OR (artist = :artist AND artist != 'Artiste inconnu')) " +
            "ORDER BY (artist = :artist) DESC, ABS(durationMs - :dur) LIMIT 25"
    )
    suspend fun similar(id: Long, genre: String, artist: String, dur: Long): List<TrackEntity>
}

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE")
    fun all(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE id = :id")
    fun observe(id: Long): Flow<PlaylistEntity?>

    @Insert
    suspend fun create(p: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM playlist_items WHERE playlistId = :id")
    suspend fun clearItems(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addItem(i: PlaylistItem)

    @Query("DELETE FROM playlist_items WHERE playlistId = :pid AND trackId = :tid")
    suspend fun removeItem(pid: Long, tid: Long)

    @Query("SELECT COALESCE(MAX(position), 0) + 1 FROM playlist_items WHERE playlistId = :pid")
    suspend fun nextPos(pid: Long): Int

    @Query("SELECT t.* FROM tracks t JOIN playlist_items p ON t.id = p.trackId WHERE p.playlistId = :pid ORDER BY p.position")
    fun tracks(pid: Long): Flow<List<TrackEntity>>
}

@Dao
interface HistoryDao {
    @Insert
    suspend fun insert(h: HistoryEntity)

    @Query("SELECT t.* FROM tracks t JOIN (SELECT trackId, MAX(playedAt) AS m FROM history GROUP BY trackId) h ON t.id = h.trackId ORDER BY h.m DESC LIMIT 50")
    fun recent(): Flow<List<TrackEntity>>

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Dao
interface HotCueDao {
    @Query("SELECT * FROM hot_cues WHERE trackId = :trackId")
    suspend fun forTrack(trackId: Long): List<HotCueEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(c: HotCueEntity)

    @Query("DELETE FROM hot_cues WHERE trackId = :trackId AND slot = :slot")
    suspend fun delete(trackId: Long, slot: Int)
}

@Database(
    entities = [TrackEntity::class, PlaylistEntity::class, PlaylistItem::class, HistoryEntity::class, HotCueEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FusionDb : RoomDatabase() {
    abstract fun trackDao(): TrackDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun historyDao(): HistoryDao
    abstract fun hotCueDao(): HotCueDao
}
