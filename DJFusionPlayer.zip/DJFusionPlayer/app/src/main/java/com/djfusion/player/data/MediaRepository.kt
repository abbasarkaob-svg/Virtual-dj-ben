package com.djfusion.player.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Accès unique à la base + indexation progressive des fichiers (Storage Access Framework). */
class MediaRepository(private val ctx: Context, val db: FusionDb) {
    private val dao = db.trackDao()

    private val audioExt = setOf("mp3", "aac", "m4a", "wav", "flac", "ogg", "opus", "oga")
    private val videoExt = setOf("mp4", "mkv", "webm", "mov", "m4v", "3gp")

    /** 0 = ignoré, 1 = audio, 2 = vidéo */
    private fun classify(name: String?, mime: String?): Int {
        val ext = name?.substringAfterLast('.', "")?.lowercase().orEmpty()
        return when {
            ext in audioExt -> 1
            ext in videoExt -> 2
            mime?.startsWith("audio/") == true -> 1
            mime?.startsWith("video/") == true -> 2
            else -> 0
        }
    }

    private fun readTrack(uri: Uri, name: String?, mime: String?, folder: String): TrackEntity? {
        val kind = classify(name, mime)
        if (kind == 0) return null
        val fallbackTitle = name?.substringBeforeLast('.') ?: "Sans titre"
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            fun m(k: Int) = r.extractMetadata(k)?.takeIf { it.isNotBlank() }
            TrackEntity(
                uri = uri.toString(),
                title = m(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: fallbackTitle,
                artist = m(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "Artiste inconnu",
                album = m(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "Album inconnu",
                genre = m(MediaMetadataRetriever.METADATA_KEY_GENRE) ?: "Inconnu",
                durationMs = m(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                folder = folder,
                isVideo = kind == 2
            )
        } catch (e: Exception) {
            TrackEntity(uri = uri.toString(), title = fallbackTitle, artist = "Artiste inconnu", album = "Album inconnu",
                genre = "Inconnu", durationMs = 0L, folder = folder, isVideo = kind == 2)
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Parcours récursif d'un dossier choisi par l'utilisateur ; insertion par lots de 20 (progressif). */
    suspend fun scanTree(tree: Uri, onProgress: (Int) -> Unit) = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return@withContext
        val batch = ArrayList<TrackEntity>()
        var n = 0
        suspend fun flush() {
            if (batch.isNotEmpty()) {
                dao.insertAll(batch.toList()); batch.clear(); onProgress(n)
            }
        }
        suspend fun walk(dir: DocumentFile, path: String) {
            for (f in dir.listFiles()) {
                currentCoroutineContext().ensureActive()
                if (f.isDirectory) {
                    walk(f, path + "/" + (f.name ?: ""))
                } else {
                    val t = readTrack(f.uri, f.name, f.type, path)
                    if (t != null) {
                        batch.add(t); n++
                        if (batch.size >= 20) flush()
                    }
                }
            }
        }
        walk(root, root.name ?: "Dossier")
        flush()
    }

    suspend fun addUris(uris: List<Uri>) = withContext(Dispatchers.IO) {
        for (u in uris) {
            val df = DocumentFile.fromSingleUri(ctx, u)
            readTrack(u, df?.name, df?.type, "Fichiers")?.let { dao.insertAll(listOf(it)) }
        }
    }

    suspend fun addOne(uri: Uri, name: String, mime: String?, folder: String) = withContext(Dispatchers.IO) {
        readTrack(uri, name, mime, folder)?.let { dao.insertAll(listOf(it)) }
    }

    suspend fun toggleFavorite(t: TrackEntity) = dao.setFavorite(t.id, !t.favorite)
    suspend fun remove(t: TrackEntity) = dao.delete(t.id)
    suspend fun clear() = dao.deleteAll()
}
