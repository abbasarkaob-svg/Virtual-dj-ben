package com.djfusion.player.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "settings")

data class Prefs(
    val lightMode: Boolean = false,
    val smartMix: Boolean = false,
    val fadeSec: Int = 5,
    val dlTree: String? = null,
    val lastId: Long = -1L,
    val lastPos: Long = 0L,
    val trees: Set<String> = emptySet()
)

class SettingsStore(private val ctx: Context) {
    private val LIGHT = booleanPreferencesKey("light")
    private val SMART = booleanPreferencesKey("smart")
    private val FADE = intPreferencesKey("fade")
    private val TREE = stringPreferencesKey("dl_tree")
    private val LAST_ID = longPreferencesKey("last_id")
    private val LAST_POS = longPreferencesKey("last_pos")
    private val TREES = stringSetPreferencesKey("trees")

    val data: Flow<Prefs> = ctx.dataStore.data.map { p ->
        Prefs(
            lightMode = p[LIGHT] ?: false,
            smartMix = p[SMART] ?: false,
            fadeSec = p[FADE] ?: 5,
            dlTree = p[TREE],
            lastId = p[LAST_ID] ?: -1L,
            lastPos = p[LAST_POS] ?: 0L,
            trees = p[TREES] ?: emptySet()
        )
    }

    suspend fun setLight(b: Boolean) { ctx.dataStore.edit { it[LIGHT] = b } }
    suspend fun setSmart(b: Boolean) { ctx.dataStore.edit { it[SMART] = b } }
    suspend fun setFade(s: Int) { ctx.dataStore.edit { it[FADE] = s } }
    suspend fun setDownloadTree(s: String?) {
        ctx.dataStore.edit { if (s == null) it.remove(TREE) else it[TREE] = s }
    }
    suspend fun addScanTree(s: String) { ctx.dataStore.edit { it[TREES] = (it[TREES] ?: emptySet()) + s } }
    suspend fun clearScanTrees() { ctx.dataStore.edit { it.remove(TREES) } }
    suspend fun saveLast(id: Long, pos: Long) {
        ctx.dataStore.edit { it[LAST_ID] = id; it[LAST_POS] = pos }
    }
}
