package com.djfusion.player.djengine

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.djfusion.player.data.HotCueEntity
import com.djfusion.player.data.MediaRepository
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.domain.DeckState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Une platine : son propre ExoPlayer (mixage réel simultané) + chaîne d'effets DeckFx. */
@UnstableApi
class Deck(
    private val ctx: Context,
    val name: String,
    private val scope: CoroutineScope,
    private val repo: MediaRepository,
    private val isLight: () -> Boolean
) {
    val fx = DeckFx()
    val player: ExoPlayer
    val state = MutableStateFlow(DeckState())
    var xGain = 1f
        set(v) { field = v; applyVolume() }

    private var previewing = false
    private var nudge = 0f
    private val taps = ArrayList<Long>()

    init {
        val rf = object : DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context)
                .setAudioProcessors(arrayOf<AudioProcessor>(fx))
                .setEnableFloatOutput(enableFloatOutput)
                .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                .build()
        }
        // Pas de gestion du focus audio : les deux platines doivent jouer en même temps.
        player = ExoPlayer.Builder(ctx, rf).build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { state.update { it.copy(playing = isPlaying) } }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && player.duration > 0) state.update { it.copy(durMs = player.duration) }
                if (playbackState == Player.STATE_ENDED) state.update { it.copy(playing = false, posMs = it.durMs) }
            }
            override fun onPlayerError(error: PlaybackException) {
                state.update { it.copy(error = error.errorCodeName, playing = false) }
            }
        })
        scope.launch {
            var n = 0
            while (true) { delay(20); tick(++n) }
        }
    }

    private fun tick(n: Int) {
        if (!player.isPlaying) return
        val s = state.value
        val pos = player.currentPosition
        val li = s.loopIn; val lo = s.loopOut
        if (s.loopActive && li != null && lo != null && pos >= lo) player.seekTo(li)
        if (n % (if (isLight()) 8 else 3) == 0) state.update { it.copy(posMs = player.currentPosition) }
    }

    private fun pos() = player.currentPosition

    // ------------------------------------------------------------ chargement
    fun load(t: TrackEntity) {
        player.setMediaItem(MediaItem.fromUri(t.uri))
        player.prepare()
        player.pause()
        state.update {
            it.copy(track = t, playing = false, posMs = 0, durMs = t.durationMs, cueMs = 0, hotCues = emptyMap(),
                loopIn = null, loopOut = null, loopActive = false, waveform = FloatArray(0), error = null)
        }
        applySpeed()
        scope.launch(Dispatchers.IO) {
            val cues = repo.db.hotCueDao().forTrack(t.id).associate { it.slot to it.positionMs }
            state.update { if (it.track?.id == t.id) it.copy(hotCues = cues) else it }
            val wf = WaveformExtractor.extract(ctx, Uri.parse(t.uri))
            state.update { if (it.track?.id == t.id) it.copy(waveform = wf) else it }
        }
    }

    // ------------------------------------------------------------ transport
    fun playPause() {
        if (state.value.track == null) return
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }

    fun play() { if (state.value.track != null && !player.isPlaying) playPause() }
    fun pause() { player.pause() }

    fun seekTo(ms: Long) {
        val max = state.value.durMs.takeIf { it > 0 } ?: Long.MAX_VALUE
        val m = ms.coerceIn(0, max)
        player.seekTo(m)
        state.update { it.copy(posMs = m) }
    }

    fun seekFraction(f: Float) = seekTo((state.value.durMs * f.coerceIn(0f, 1f)).toLong())

    /** CUE style CDJ : en lecture → retour au point CUE ; à l'arrêt → pose le CUE, maintenir = pré-écoute. */
    fun cuePress() {
        val s = state.value
        if (s.track == null) return
        if (player.isPlaying) {
            player.pause(); seekTo(s.cueMs)
        } else if (kotlin.math.abs(pos() - s.cueMs) > 60) {
            state.update { it.copy(cueMs = pos()) }
        } else {
            previewing = true; player.play()
        }
    }

    fun cueRelease() {
        if (previewing) {
            previewing = false
            player.pause(); seekTo(state.value.cueMs)
        }
    }

    // ------------------------------------------------------------ hot cues
    private fun persist(slot: Int, ms: Long) {
        val t = state.value.track ?: return
        scope.launch(Dispatchers.IO) { repo.db.hotCueDao().upsert(HotCueEntity(t.id, slot, ms)) }
    }

    fun hotCue(slot: Int) {
        val c = state.value.hotCues[slot]
        if (c == null) setHotCueHere(slot) else { seekTo(c); if (!player.isPlaying) player.play() }
    }

    fun setHotCueHere(slot: Int) {
        if (state.value.track == null) return
        val p = pos()
        state.update { it.copy(hotCues = it.hotCues + (slot to p)) }
        persist(slot, p)
    }

    fun jumpHotCue(slot: Int) { state.value.hotCues[slot]?.let { seekTo(it) } }

    fun nudgeHotCue(slot: Int, delta: Long) {
        val c = state.value.hotCues[slot] ?: return
        val n = (c + delta).coerceAtLeast(0)
        state.update { it.copy(hotCues = it.hotCues + (slot to n)) }
        persist(slot, n)
    }

    fun deleteHotCue(slot: Int) {
        val t = state.value.track ?: return
        state.update { it.copy(hotCues = it.hotCues - slot) }
        scope.launch(Dispatchers.IO) { repo.db.hotCueDao().delete(t.id, slot) }
    }

    // ------------------------------------------------------------ boucles
    fun loopIn() { val p = pos(); state.update { it.copy(loopIn = p, loopOut = null, loopActive = false) } }
    fun loopOut() {
        val i = state.value.loopIn ?: return
        val p = pos()
        if (p > i + 50) state.update { it.copy(loopOut = p, loopActive = true) }
    }
    fun toggleLoop() {
        val s = state.value
        if (s.loopIn != null && s.loopOut != null) state.update { it.copy(loopActive = !it.loopActive) }
    }
    fun autoLoop(beats: Float) {
        if (state.value.track == null) return
        val len = (beats * 60000f / state.value.bpm).toLong()
        val i = pos()
        state.update { it.copy(loopIn = i, loopOut = i + len, loopActive = true) }
    }

    fun tapBpm() {
        val now = SystemClock.elapsedRealtime()
        if (taps.isNotEmpty() && now - taps.last() > 2500) taps.clear()
        taps.add(now)
        if (taps.size > 8) taps.removeAt(0)
        if (taps.size >= 3) {
            val avg = (taps.last() - taps.first()).toFloat() / (taps.size - 1)
            state.update { it.copy(bpm = (60000f / avg).coerceIn(60f, 200f)) }
        }
    }

    // ------------------------------------------------------------ pitch / vitesse
    private fun applySpeed() {
        val s = state.value
        var sp = (1f + s.tempo) * (1f + 0.08f * s.bend) + nudge
        sp = sp.coerceIn(0.3f, 2f)
        player.playbackParameters = PlaybackParameters(sp, if (s.keyLock) 1f else sp)
    }

    fun setTempo(t: Float) { state.update { it.copy(tempo = t.coerceIn(-0.5f, 0.5f)) }; applySpeed() }
    fun toggleKeyLock() { state.update { it.copy(keyLock = !it.keyLock) }; applySpeed() }
    fun bend(dir: Int) { state.update { it.copy(bend = dir) }; applySpeed() }

    fun jog(deg: Float) {
        if (state.value.track == null) return
        if (player.isPlaying) { nudge = (deg / 12f * 0.06f).coerceIn(-0.3f, 0.3f); applySpeed() }
        else seekTo(pos() + (deg * 6).toLong())
    }
    fun jogEnd() { nudge = 0f; applySpeed() }

    // ------------------------------------------------------------ mixage
    private fun dbOf(v: Float) = if (v < 0) v * 36f else v * 6f

    private fun pushFx() {
        val s = state.value
        fx.update(dbOf(s.low), dbOf(s.mid), dbOf(s.high), s.filter)
    }

    fun setLow(v: Float) { state.update { it.copy(low = v) }; pushFx() }
    fun setMid(v: Float) { state.update { it.copy(mid = v) }; pushFx() }
    fun setHigh(v: Float) { state.update { it.copy(high = v) }; pushFx() }
    fun setFilter(v: Float) { state.update { it.copy(filter = v) }; pushFx() }
    fun setVolume(v: Float) { state.update { it.copy(volume = v.coerceIn(0f, 1f)) }; applyVolume() }
    fun applyVolume() { player.volume = (state.value.volume * xGain).coerceIn(0f, 1f) }

    fun release() { player.release() }
}
