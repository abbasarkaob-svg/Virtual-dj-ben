package com.djfusion.player.djengine

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.*

/** Filtre biquad (RBJ cookbook), état par canal. */
class Biquad {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f; private var a1 = 0f; private var a2 = 0f
    private val z1 = FloatArray(2); private val z2 = FloatArray(2)
    var on = false

    fun reset() { z1.fill(0f); z2.fill(0f) }

    fun process(c: Int, x: Float): Float {
        val y = b0 * x + z1[c]
        z1[c] = b1 * x - a1 * y + z2[c]
        z2[c] = b2 * x - a2 * y
        return y
    }

    private fun set(nb0: Double, nb1: Double, nb2: Double, na0: Double, na1: Double, na2: Double) {
        b0 = (nb0 / na0).toFloat(); b1 = (nb1 / na0).toFloat(); b2 = (nb2 / na0).toFloat()
        a1 = (na1 / na0).toFloat(); a2 = (na2 / na0).toFloat(); on = true
    }

    fun lowPass(f: Double, sr: Int, q: Double) {
        val w = 2 * PI * f / sr; val c = cos(w); val al = sin(w) / (2 * q)
        set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun highPass(f: Double, sr: Int, q: Double) {
        val w = 2 * PI * f / sr; val c = cos(w); val al = sin(w) / (2 * q)
        set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun peaking(f: Double, sr: Int, q: Double, gainDb: Double) {
        val w = 2 * PI * f / sr; val c = cos(w); val al = sin(w) / (2 * q); val a = 10.0.pow(gainDb / 40)
        set(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
    }

    fun lowShelf(f: Double, sr: Int, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40); val w = 2 * PI * f / sr; val c = cos(w); val s = sin(w)
        val beta = 2 * sqrt(a) * (s / sqrt(2.0))
        set(
            a * ((a + 1) - (a - 1) * c + beta), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - beta),
            (a + 1) + (a - 1) * c + beta, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - beta
        )
    }

    fun highShelf(f: Double, sr: Int, gainDb: Double) {
        val a = 10.0.pow(gainDb / 40); val w = 2 * PI * f / sr; val c = cos(w); val s = sin(w)
        val beta = 2 * sqrt(a) * (s / sqrt(2.0))
        set(
            a * ((a + 1) + (a - 1) * c + beta), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - beta),
            (a + 1) - (a - 1) * c + beta, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - beta
        )
    }
}

/**
 * Traitement audio temps réel d'une platine, inséré dans la chaîne ExoPlayer :
 * égaliseur 3 bandes (grave / médium / aigu) + filtre DJ (passe-bas <0 / passe-haut >0).
 */
@UnstableApi
class DeckFx : BaseAudioProcessor() {
    @Volatile private var lowDb = 0f
    @Volatile private var midDb = 0f
    @Volatile private var highDb = 0f
    @Volatile private var filter = 0f
    @Volatile private var dirty = true

    private var sampleRate = 44100
    private var channels = 2
    private var isFloat = false
    private val stages = Array(4) { Biquad() }

    fun update(low: Float, mid: Float, high: Float, filt: Float) {
        lowDb = low; midDb = mid; highDb = high; filter = filt; dirty = true
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val enc = inputAudioFormat.encoding
        if (inputAudioFormat.channelCount !in 1..2 || (enc != C.ENCODING_PCM_16BIT && enc != C.ENCODING_PCM_FLOAT)) {
            return AudioProcessor.AudioFormat.NOT_SET // format non géré : le processeur est contourné
        }
        sampleRate = inputAudioFormat.sampleRate
        channels = inputAudioFormat.channelCount
        isFloat = enc == C.ENCODING_PCM_FLOAT
        stages.forEach { it.reset() }
        dirty = true
        return inputAudioFormat
    }

    private fun recompute() {
        dirty = false
        val sr = sampleRate
        val nyq = sr * 0.45
        stages[0].apply { if (lowDb != 0f) lowShelf(250.0, sr, lowDb.toDouble()) else on = false }
        stages[1].apply { if (midDb != 0f) peaking(1500.0, sr, 0.7, midDb.toDouble()) else on = false }
        stages[2].apply { if (highDb != 0f) highShelf(4500.0, sr, highDb.toDouble()) else on = false }
        val f = filter
        stages[3].apply {
            when {
                f < -0.02f -> lowPass(min(20000.0 * (80.0 / 20000.0).pow(-f.toDouble()), nyq), sr, 0.8)
                f > 0.02f -> highPass(20.0 * (8000.0 / 20.0).pow(f.toDouble()), sr, 0.8)
                else -> on = false
            }
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        if (dirty) recompute()
        val active = stages.filter { it.on }
        if (active.isEmpty()) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        val bytesPerSample = if (isFloat) 4 else 2
        val frames = size / (bytesPerSample * channels)
        for (i in 0 until frames) {
            for (c in 0 until channels) {
                var x = if (isFloat) inputBuffer.getFloat() else inputBuffer.getShort() / 32768f
                for (s in active) x = s.process(c, x)
                if (isFloat) out.putFloat(x)
                else out.putShort((x.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
            }
        }
        inputBuffer.position(inputBuffer.limit())
        out.limit(frames * bytesPerSample * channels)
        out.position(0)
    }
}
