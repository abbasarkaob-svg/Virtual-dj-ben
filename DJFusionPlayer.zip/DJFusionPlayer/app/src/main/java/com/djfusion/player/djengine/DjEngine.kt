package com.djfusion.player.djengine

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.SystemClock
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.data.MediaRepository
import com.djfusion.player.data.SettingsStore
import com.djfusion.player.domain.SmartMix
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** Studio DJ : deux platines + crossfader (gain à puissance constante) + Smart Mix local. */
@UnstableApi
class DjEngine(
    private val ctx: Context,
    private val repo: MediaRepository,
    private val settings: SettingsStore,
    private val scope: CoroutineScope
) {
    private val _light = MutableStateFlow(false)
    val light: StateFlow<Boolean> = _light
    private val _smart = MutableStateFlow(false)
    val smartMix: StateFlow<Boolean> = _smart
    private val _fade = MutableStateFlow(5)
    val autoFadeSec: StateFlow<Int> = _fade
    private val _cross = MutableStateFlow(0f)
    val cross: StateFlow<Float> = _cross
    private val _advice = MutableStateFlow("")
    val advice: StateFlow<String> = _advice

    val decks = listOf(
        Deck(ctx, "A", scope, repo) { _light.value },
        Deck(ctx, "B", scope, repo) { _light.value }
    )
    private var fadeJob: Job? = null

    init {
        scope.launch {
            settings.data.collect { _light.value = it.lightMode; _smart.value = it.smartMix; _fade.value = it.fadeSec }
        }
        setCross(0f)
        scope.launch {
            while (true) { delay(500); evaluateSmart() }
        }
    }

    fun setSmartMix(b: Boolean) { scope.launch { settings.setSmart(b) } }
    fun setLightMode(b: Boolean) { scope.launch { settings.setLight(b) } }
    fun setFadeSec(s: Int) { scope.launch { settings.setFade(s) } }

    /** Crossfader : x ∈ [-1 (A), +1 (B)]. Courbe à puissance constante. */
    fun setCross(x: Float) {
        val v = x.coerceIn(-1f, 1f)
        _cross.value = v
        val t = (v + 1f) * (PI.toFloat() / 4f)
        decks[0].xGain = cos(t)
        decks[1].xGain = sin(t)
    }

    fun autoFade(to: Int, durMs: Long = _fade.value * 1000L) {
        fadeJob?.cancel()
        fadeJob = scope.launch {
            val target = if (to == 0) -1f else 1f
            val start = _cross.value
            val dst = decks[to]
            val src = decks[1 - to]
            if (!dst.state.value.playing && dst.state.value.track != null) dst.play()
            val origLow = src.state.value.low
            val t0 = SystemClock.elapsedRealtime()
            try {
                while (true) {
                    val k = ((SystemClock.elapsedRealtime() - t0) / durMs.toFloat()).coerceIn(0f, 1f)
                    setCross(start + (target - start) * k)
                    // Smart Mix : permutation des basses pendant la 2e moitié du fondu
                    if (_smart.value) src.setLow(origLow + (-1f - origLow) * ((k - 0.5f) * 2f).coerceIn(0f, 1f))
                    if (k >= 1f) break
                    delay(20)
                }
            } finally {
                src.setLow(origLow)
            }
            if (_smart.value) src.pause()
        }
    }

    private fun evaluateSmart() {
        val a = decks[0].state.value
        val b = decks[1].state.value
        val adv = SmartMix.advise(a, b)
        _advice.value = adv.text
        if (_smart.value && adv.triggerNow && fadeJob?.isActive != true) autoFade(adv.toDeck, adv.fadeMs)
    }

    /** Pré-écoute (casque) : route la platine vers une sortie casque filaire / USB / Bluetooth. */
    fun togglePreCue(i: Int): Boolean {
        val d = decks[i]
        val on = !d.state.value.preCue
        if (on) {
            val am = ctx.getSystemService(AudioManager::class.java)
            val types = setOf(
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
            )
            val dev = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.type in types } ?: return false
            d.player.setPreferredAudioDevice(dev)
        } else {
            d.player.setPreferredAudioDevice(null)
        }
        d.state.value = d.state.value.copy(preCue = on)
        return true
    }
}
