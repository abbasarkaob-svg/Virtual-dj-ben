package com.djfusion.player.djengine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.abs

/** Calcule les pics de la forme d'onde en décodant le fichier (à appeler hors thread principal). */
object WaveformExtractor {
    fun extract(ctx: Context, uri: Uri, buckets: Int = 700): FloatArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null || !fmt.containsKey(MediaFormat.KEY_DURATION)) return FloatArray(0)
            val durUs = fmt.getLong(MediaFormat.KEY_DURATION)
            if (durUs <= 0) return FloatArray(0)
            ex.selectTrack(idx)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val peaks = FloatArray(buckets)
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5000)
                if (o >= 0) {
                    if (info.size > 0) {
                        val out = codec.getOutputBuffer(o)!!
                        out.order(ByteOrder.nativeOrder())
                        val sb = out.asShortBuffer()
                        val b = ((info.presentationTimeUs.toDouble() / durUs) * buckets).toInt().coerceIn(0, buckets - 1)
                        var m = peaks[b]
                        var k = 0
                        val n = sb.remaining()
                        while (k < n) { m = maxOf(m, abs(sb.get(sb.position() + k).toInt()) / 32768f); k += 8 }
                        peaks[b] = m
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            var mx = peaks.maxOrNull() ?: 0f
            if (mx <= 0f) mx = 1f
            for (i in peaks.indices) {
                if (peaks[i] == 0f && i > 0) peaks[i] = peaks[i - 1]
                peaks[i] = (peaks[i] / mx).coerceIn(0.03f, 1f)
            }
            return peaks
        } catch (e: Exception) {
            return FloatArray(0)
        } finally {
            try { codec?.stop(); codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
