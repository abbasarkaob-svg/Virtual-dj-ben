package com.djfusion.player.domain

import com.djfusion.player.data.TrackEntity

/** État d'une platine DJ. Egaliseur/filtre normalisés dans [-1, 1] (0 = neutre). */
data class DeckState(
    val track: TrackEntity? = null,
    val playing: Boolean = false,
    val posMs: Long = 0,
    val durMs: Long = 0,
    val tempo: Float = 0f,          // -0.5 .. +0.5 (pitch ±50 %)
    val keyLock: Boolean = false,
    val bend: Int = 0,              // -1, 0, +1 (pitch bend momentané)
    val low: Float = 0f,
    val mid: Float = 0f,
    val high: Float = 0f,
    val filter: Float = 0f,         // <0 passe-bas, >0 passe-haut
    val volume: Float = 1f,
    val cueMs: Long = 0,
    val hotCues: Map<Int, Long> = emptyMap(),
    val loopIn: Long? = null,
    val loopOut: Long? = null,
    val loopActive: Boolean = false,
    val bpm: Float = 120f,          // renseigné par TAP (aucune IA / analyse cloud)
    val waveform: FloatArray = FloatArray(0),
    val preCue: Boolean = false,
    val error: String? = null
)

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}
