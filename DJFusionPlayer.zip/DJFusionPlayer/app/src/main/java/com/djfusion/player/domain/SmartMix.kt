package com.djfusion.player.domain

import kotlin.math.min

/**
 * Smart Mix : règles purement locales (aucune IA). Propose le moment et la durée d'une transition
 * à partir des durées restantes et de l'état des platines.
 */
object SmartMix {
    data class Advice(val text: String, val fromDeck: Int = -1, val toDeck: Int = -1, val fadeMs: Long = 0, val triggerNow: Boolean = false)

    fun idealFadeMs(a: DeckState, b: DeckState): Long =
        (min(a.durMs.takeIf { it > 0 } ?: 120_000, b.durMs.takeIf { it > 0 } ?: 120_000) / 20).coerceIn(4_000, 16_000)

    fun advise(a: DeckState, b: DeckState): Advice {
        val names = listOf("A", "B")
        val decks = listOf(a, b)
        if (a.track == null && b.track == null) return Advice("Chargez une piste sur chaque platine")
        if (a.playing && b.playing) {
            val tempoGap = Math.abs((a.tempo - b.tempo) * 100)
            return if (tempoGap > 3) Advice("Écart de tempo de ${"%.1f".format(tempoGap)} % : ajustez le pitch avant de mixer")
            else Advice("Les deux platines jouent : coupez les basses de la platine sortante")
        }
        val from = when { a.playing -> 0; b.playing -> 1; else -> -1 }
        if (from == -1) return Advice("Lancez une platine pour démarrer le set")
        val to = 1 - from
        val f = decks[from]; val t = decks[to]
        if (t.track == null) return Advice("Chargez la prochaine piste sur la platine ${names[to]}")
        val fade = idealFadeMs(f, t)
        val remaining = f.durMs - f.posMs
        return when {
            remaining <= fade + 500 -> Advice("Transition maintenant vers ${names[to]} (${fade / 1000}s)", from, to, fade, true)
            remaining < fade + 15_000 -> Advice("Transition vers ${names[to]} dans ${(remaining - fade) / 1000}s (fondu ${fade / 1000}s)", from, to, fade)
            else -> Advice("Platine ${names[from]} en cours — prochaine transition dans ${(remaining - fade) / 1000}s")
        }
    }
}
