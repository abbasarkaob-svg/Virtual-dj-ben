package com.djfusion.player.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.util.UnstableApi
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.Data
import androidx.work.workDataOf
import com.djfusion.player.container
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

/**
 * Télécharge une URL HTTPS vers Download/DJ Fusion Player (MediaStore), ou vers un dossier choisi
 * avec le Storage Access Framework. Progression publiée, annulation propre (fichier partiel supprimé).
 */
@UnstableApi
class DownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val url = inputData.getString("url") ?: return@withContext fail("URL manquante")
        val name = inputData.getString("name") ?: "download"
        val tree = inputData.getString("tree")
        if (!url.startsWith("https://", true)) return@withContext fail("HTTPS requis")

        val resolver = applicationContext.contentResolver
        var itemUri: Uri? = null
        var docFile: DocumentFile? = null
        var conn: HttpURLConnection? = null
        var success = false
        try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 20000; instanceFollowRedirects = true
            }
            conn.connect()
            if (conn.responseCode !in 200..299) return@withContext fail("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                ?: conn.contentType?.substringBefore(';') ?: "application/octet-stream"

            val out: OutputStream = if (tree != null) {
                val dir = DocumentFile.fromTreeUri(applicationContext, Uri.parse(tree)) ?: return@withContext fail("Dossier inaccessible")
                docFile = dir.createFile(mime, name) ?: return@withContext fail("Création du fichier impossible")
                resolver.openOutputStream(docFile.uri)!!
            } else {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, "Download/DJ Fusion Player")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return@withContext fail("MediaStore indisponible")
                resolver.openOutputStream(itemUri!!)!!
            }

            out.use { os ->
                conn.inputStream.use { input ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var lastReport = 0L
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - lastReport > 250) {
                            lastReport = now
                            setProgress(workDataOf("p" to (if (total > 0) (done * 100 / total).toInt() else -1), "bytes" to done))
                        }
                    }
                }
            }
            success = true
            val finalUri: Uri
            if (itemUri != null) {
                resolver.update(itemUri!!, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                finalUri = itemUri!!
            } else finalUri = docFile!!.uri
            // Ajout automatique à la bibliothèque si c'est un média
            applicationContext.container.repo.addOne(finalUri, name, mime, "Download/DJ Fusion Player")
            Result.success(workDataOf("p" to 100))
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            fail(e.message ?: "Erreur réseau")
        } finally {
            conn?.disconnect()
            if (!success) {
                try { itemUri?.let { resolver.delete(it, null, null) } } catch (_: Exception) {}
                try { docFile?.delete() } catch (_: Exception) {}
            }
        }
    }

    private fun fail(msg: String): Result = Result.failure(Data.Builder().putString("error", msg).build())
}
