package com.djfusion.player.playback

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.media3.common.*
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.djfusion.player.data.HistoryEntity
import com.djfusion.player.data.MediaRepository
import com.djfusion.player.data.SettingsStore
import com.djfusion.player.data.TrackEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class PlayState(
    val track: TrackEntity? = null,
    val playing: Boolean = false,
    val pos: Long = 0,
    val dur: Long = 0,
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val hasQueue: Boolean = false
)

/** Lecteur principal audio/vidéo : file d'attente, aléatoire, répétition, historique, reprise. */
@UnstableApi
class PlayerManager(
    private val ctx: Context,
    private val repo: MediaRepository,
    private val settings: SettingsStore,
    private val scope: CoroutineScope
) {
    val player: ExoPlayer = ExoPlayer.Builder(ctx)
        .setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
            true // gestion du focus audio (appels, autres applications)
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_LOCAL)
        .build()

    private var queue: List<TrackEntity> = emptyList()
    private val _state = MutableStateFlow(PlayState())
    val state: StateFlow<PlayState> = _state

    init {
        player.addListener(object : Player.Listener {
            override fun onEvents(p: Player, events: Player.Events) {
                refresh()
                if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION) && p.isPlaying) logHistory()
                if (events.contains(Player.EVENT_IS_PLAYING_CHANGED)) {
                    if (p.isPlaying) logHistory() else saveResume()
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                if (player.hasNextMediaItem()) {
                    player.seekToNextMediaItem(); player.prepare(); player.play()
                }
            }
        })
        scope.launch {
            var n = 0
            while (true) {
                delay(400)
                if (player.isPlaying) {
                    refresh()
                    if (++n % 12 == 0) saveResume()
                }
            }
        }
    }

    private fun item(t: TrackEntity): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album).build())
        .build()

    private fun current(): TrackEntity? = queue.getOrNull(player.currentMediaItemIndex)

    private fun refresh() {
        val t = current()
        val d = player.duration
        _state.value = PlayState(
            track = t,
            playing = player.isPlaying,
            pos = player.currentPosition.coerceAtLeast(0),
            dur = if (d == C.TIME_UNSET || d <= 0) (t?.durationMs ?: 0) else d,
            shuffle = player.shuffleModeEnabled,
            repeat = player.repeatMode,
            speed = player.playbackParameters.speed,
            hasQueue = queue.isNotEmpty()
        )
    }

    private fun logHistory() {
        val t = current() ?: return
        scope.launch(Dispatchers.IO) { repo.db.historyDao().insert(HistoryEntity(trackId = t.id, playedAt = System.currentTimeMillis())) }
    }

    private fun saveResume() {
        val t = current() ?: return
        val pos = player.currentPosition
        scope.launch { settings.saveLast(t.id, pos) }
    }

    fun restore() {
        scope.launch {
            val p = settings.data.first()
            if (p.lastId > 0) {
                val t = repo.db.trackDao().byId(p.lastId) ?: return@launch
                queue = listOf(t)
                player.setMediaItem(item(t), p.lastPos)
                player.prepare()
                refresh()
            }
        }
    }

    fun play(list: List<TrackEntity>, index: Int) {
        if (list.isEmpty()) return
        queue = list
        player.setMediaItems(list.map(::item), index.coerceIn(0, list.lastIndex), 0)
        player.prepare()
        player.play()
        ctx.startService(Intent(ctx, PlaybackService::class.java))
    }

    fun togglePlay() {
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
            ctx.startService(Intent(ctx, PlaybackService::class.java))
        }
    }

    fun next() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
    fun previous() {
        if (player.currentPosition > 3000 || !player.hasPreviousMediaItem()) player.seekTo(0) else player.seekToPreviousMediaItem()
    }
    fun seekTo(ms: Long) { player.seekTo(ms); refresh() }
    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }
    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }
    fun setSpeed(s: Float) { player.setPlaybackSpeed(s); refresh() }
    fun setVolume(v: Float) { player.volume = v.coerceIn(0f, 1f) }

    /** Ajoute un fichier de sous-titres (.srt / .vtt) à la vidéo en cours sans perdre la position. */
    fun addSubtitle(uri: Uri, displayName: String?) {
        val idx = player.currentMediaItemIndex
        val cur = player.currentMediaItem ?: return
        val pos = player.currentPosition
        val mime = if (displayName?.endsWith(".vtt", true) == true) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime).setLanguage("und").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
        player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
        player.play()
    }
}
