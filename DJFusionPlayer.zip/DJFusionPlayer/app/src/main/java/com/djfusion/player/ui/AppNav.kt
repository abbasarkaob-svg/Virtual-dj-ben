package com.djfusion.player.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.djfusion.player.container
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.ui.components.MiniPlayer
import com.djfusion.player.ui.components.TrackMenu
import com.djfusion.player.ui.screens.*
import com.djfusion.player.ui.theme.FC

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(UnstableApi::class)
@Composable
fun AppNav() {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val lib: LibraryViewModel = viewModel()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Tab("home", "Accueil", Icons.Filled.Home), Tab("library", "Biblio", Icons.Filled.LibraryMusic),
        Tab("search", "Recherche", Icons.Filled.Search), Tab("dj", "Studio", Icons.Filled.Album),
        Tab("downloads", "Télécharg.", Icons.Filled.Download)
    )
    val tabRoutes = tabs.map { it.route }
    val fullScreen = route == "dj" || route == "video" || route == "hotcues"
    var playlistTarget by remember { mutableStateOf<TrackEntity?>(null) }
    val playlists by lib.playlists.collectAsState()

    val menu = remember {
        TrackMenu(
            onFavorite = { lib.toggleFavorite(it) },
            onLoadDeck = { i, t ->
                ctx.container.dj.decks[i].load(t)
                Toast.makeText(ctx, "« ${t.title} » chargé sur la platine ${if (i == 0) "A" else "B"}", Toast.LENGTH_SHORT).show()
            },
            onAddToPlaylist = { playlistTarget = it },
            onRemove = { lib.remove(it) }
        )
    }
    fun openPlayer(video: Boolean) { nav.navigate(if (video) "video" else "nowplaying") { launchSingleTop = true } }

    Scaffold(
        containerColor = FC.Bg,
        bottomBar = {
            if (!fullScreen) Column {
                if (route != "nowplaying") MiniPlayer { openPlayer(it) }
                if (route in tabRoutes) NavigationBar(containerColor = FC.Surface) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    launchSingleTop = true
                                    if (t.route != "dj") { popUpTo("home") { saveState = true }; restoreState = true }
                                }
                            },
                            icon = { Icon(t.icon, t.label) }, label = { Text(t.label) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Color.Black, indicatorColor = FC.Gold, selectedTextColor = FC.Gold, unselectedIconColor = FC.Silver, unselectedTextColor = FC.Silver)
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(if (fullScreen) PaddingValues(0.dp) else pad)) {
            composable("home") { HomeScreen(lib, menu, { nav.navigate(it) }, ::openPlayer) }
            composable("library") { LibraryScreen(lib, menu, ::openPlayer) { nav.navigate("playlist/$it") } }
            composable("search") { SearchScreen(lib, menu, ::openPlayer) }
            composable("nowplaying") { NowPlayingScreen(lib, { nav.popBackStack() }) { ctx.container.player.state.value.track?.let { playlistTarget = it } } }
            composable("video") { VideoScreen { nav.popBackStack() } }
            composable("dj") { DjStudioScreen(lib, { nav.popBackStack() }) { nav.navigate("hotcues") } }
            composable("hotcues") { HotCueScreen { nav.popBackStack() } }
            composable("downloads") { DownloadsScreen() }
            composable("playlists") { PlaylistsScreen(lib, { nav.popBackStack() }) { nav.navigate("playlist/$it") } }
            composable("playlist/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                PlaylistDetailScreen(it.arguments!!.getLong("id"), lib, menu, { nav.popBackStack() }, ::openPlayer)
            }
            composable("discovery") { DiscoveryScreen(lib, menu, { nav.popBackStack() }, ::openPlayer) }
            composable("settings") { SettingsScreen({ nav.popBackStack() }, { nav.navigate("licenses") }, lib) }
            composable("licenses") { LicensesScreen { nav.popBackStack() } }
        }
    }

    playlistTarget?.let { t ->
        var creating by remember { mutableStateOf(false) }
        if (creating) NameDialog("Nouvelle playlist", { creating = false }) { lib.createPlaylist(it, t); creating = false; playlistTarget = null }
        else AlertDialog(
            onDismissRequest = { playlistTarget = null }, title = { Text("Ajouter à une playlist") },
            text = {
                LazyColumn {
                    items(playlists, key = { it.id }) { p ->
                        TextButton(onClick = { lib.addToPlaylist(p.id, t); playlistTarget = null }) { Text(p.name) }
                    }
                    item { TextButton(onClick = { creating = true }) { Text("+ Nouvelle playlist", color = FC.Gold) } }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onClick = { playlistTarget = null }) { Text("Annuler") } }
        )
    }
}
