@file:OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)

package com.djfusion.player.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import androidx.work.*
import com.djfusion.player.container
import com.djfusion.player.data.*
import com.djfusion.player.download.DownloadWorker
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.net.URL
import java.util.UUID

@UnstableApi
class LibraryViewModel(private val app: Application) : AndroidViewModel(app) {
    private val c = app.container
    private val repo = c.repo
    private val dao = repo.db.trackDao()
    private val pdao = repo.db.playlistDao()

    private fun <T> Flow<T>.hot(init: T) = stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), init)

    val songs = dao.songs().hot(emptyList())
    val videos = dao.videos().hot(emptyList())
    val favorites = dao.favorites().hot(emptyList())
    val recent = repo.db.historyDao().recent().hot(emptyList())
    val playlists = pdao.all().hot(emptyList())
    val count = dao.count().hot(0)
    val genres = dao.genres().hot(emptyList())

    val scanning = MutableStateFlow(false)
    val scanned = MutableStateFlow(0)

    val query = MutableStateFlow("")
    val results = query.debounce(200).flatMapLatest { q ->
        if (q.isBlank()) flowOf(emptyList()) else dao.search(q.trim())
    }.hot(emptyList())

    fun scanTree(uri: Uri) {
        try { app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        viewModelScope.launch { c.settings.addScanTree(uri.toString()); scan(listOf(uri)) }
    }

    fun rescanAll() {
        viewModelScope.launch { scan(c.settings.data.first().trees.map { Uri.parse(it) }) }
    }

    private suspend fun scan(trees: List<Uri>) {
        if (scanning.value) return
        scanning.value = true; scanned.value = 0
        try { trees.forEach { repo.scanTree(it) { n -> scanned.value = n } } } finally { scanning.value = false }
    }

    fun addFiles(uris: List<Uri>) {
        uris.forEach { try { app.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
        viewModelScope.launch { repo.addUris(uris) }
    }

    fun toggleFavorite(t: TrackEntity) { viewModelScope.launch { repo.toggleFavorite(t) } }
    fun remove(t: TrackEntity) { viewModelScope.launch { repo.remove(t) } }
    fun clearLibrary() { viewModelScope.launch { repo.clear(); c.settings.clearScanTrees() } }

    fun createPlaylist(name: String, thenAdd: TrackEntity? = null) {
        viewModelScope.launch {
            val id = pdao.create(PlaylistEntity(name = name.trim().ifEmpty { "Playlist" }))
            if (thenAdd != null) addToPlaylist(id, thenAdd)
        }
    }
    fun deletePlaylist(id: Long) { viewModelScope.launch { pdao.clearItems(id); pdao.delete(id) } }
    fun addToPlaylist(pid: Long, t: TrackEntity) {
        viewModelScope.launch { pdao.addItem(PlaylistItem(pid, t.id, pdao.nextPos(pid))) }
    }
    fun removeFromPlaylist(pid: Long, t: TrackEntity) { viewModelScope.launch { pdao.removeItem(pid, t.id) } }
    fun playlistTracks(id: Long) = pdao.tracks(id)
    fun playlist(id: Long) = pdao.observe(id)

    fun byGenre(g: String) = dao.byGenre(g)
    suspend fun similar(t: TrackEntity) = dao.similar(t.id, t.genre, t.artist, t.durationMs)
    fun observeTrack(id: Long) = dao.observe(id)
}

@UnstableApi
class DownloadViewModel(private val app: Application) : AndroidViewModel(app) {
    private val wm = WorkManager.getInstance(app)
    val works = wm.getWorkInfosByTagFlow("dl")

    /** @return un message d'erreur, ou null si le téléchargement a été mis en file. */
    fun enqueue(rawUrl: String, rawName: String?): String? {
        val url = rawUrl.trim()
        if (!url.startsWith("https://", ignoreCase = true)) return "Seules les URL HTTPS directes sont acceptées."
        val parsed = try { URL(url) } catch (e: Exception) { return "URL invalide." }
        val fromUrl = parsed.path.substringAfterLast('/').ifBlank { "download_${System.currentTimeMillis()}" }
        val name = (rawName?.takeIf { it.isNotBlank() } ?: fromUrl).replace(Regex("[\\\\/:*?\"<>|]"), "_")
        viewModelScope.launch {
            val tree = app.container.settings.data.first().dlTree
            val req = OneTimeWorkRequestBuilder<DownloadWorker>()
                .setInputData(workDataOf("url" to url, "name" to name, "tree" to tree))
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .addTag("dl").addTag("n:$name")
                .build()
            // File d'attente séquentielle : les téléchargements s'enchaînent l'un après l'autre.
            wm.beginUniqueWork("dl_queue", ExistingWorkPolicy.APPEND_OR_REPLACE, req).enqueue()
        }
        return null
    }

    fun cancel(id: UUID) { wm.cancelWorkById(id) }
    fun clearFinished() { wm.pruneWork() }
    fun setTree(uri: Uri?) {
        if (uri != null) try {
            app.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {}
        viewModelScope.launch { app.container.settings.setDownloadTree(uri?.toString()) }
    }
}

@UnstableApi
class SettingsViewModel(private val app: Application) : AndroidViewModel(app) {
    private val s = app.container.settings
    val prefs = s.data.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), Prefs())
    fun setLight(b: Boolean) { viewModelScope.launch { s.setLight(b) } }
    fun setSmart(b: Boolean) { viewModelScope.launch { s.setSmart(b) } }
    fun setFade(v: Int) { viewModelScope.launch { s.setFade(v) } }
    fun clearHistory() { viewModelScope.launch { app.container.db.historyDao().clear() } }
}
