package com.djfusion.player.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.data.ArtCache
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.domain.fmtTime
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.theme.FC
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun Context.findActivity(): Activity? {
    var c = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

/** Actions communes aux listes de morceaux (menu ⋮). */
class TrackMenu(
    val onFavorite: (TrackEntity) -> Unit,
    val onLoadDeck: (Int, TrackEntity) -> Unit,
    val onAddToPlaylist: (TrackEntity) -> Unit,
    val onRemove: (TrackEntity) -> Unit
)

@Composable
fun ArtImage(uri: String, video: Boolean, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { ArtCache.load(ctx, uri, video) }
    }
    Box(modifier.background(FC.Surface2), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(if (video) Icons.Filled.Movie else Icons.Filled.MusicNote, null, tint = FC.Gold, modifier = Modifier.fillMaxSize(0.5f))
    }
}

@Composable
fun TrackRow(
    t: TrackEntity,
    menu: TrackMenu,
    highlight: Boolean = false,
    extra: Pair<String, (TrackEntity) -> Unit>? = null,
    onClick: () -> Unit
) {
    var open by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ArtImage(t.uri, t.isVideo, Modifier.size(46.dp).clip(RoundedCornerShape(6.dp)))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = if (highlight) FC.Green else FC.White, fontSize = 15.sp)
            Text("${t.artist} • ${fmtTime(t.durationMs)}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = FC.Silver, fontSize = 12.sp)
        }
        if (t.favorite) Icon(Icons.Filled.Favorite, null, tint = FC.Gold, modifier = Modifier.size(16.dp))
        Box {
            IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, "Menu", tint = FC.Silver) }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(
                    text = { Text(if (t.favorite) "Retirer des favoris" else "Ajouter aux favoris") },
                    onClick = { open = false; menu.onFavorite(t) })
                DropdownMenuItem(text = { Text("Ajouter à une playlist") }, onClick = { open = false; menu.onAddToPlaylist(t) })
                if (!t.isVideo) {
                    DropdownMenuItem(text = { Text("Charger sur la platine A") }, onClick = { open = false; menu.onLoadDeck(0, t) })
                    DropdownMenuItem(text = { Text("Charger sur la platine B") }, onClick = { open = false; menu.onLoadDeck(1, t) })
                }
                if (extra != null) DropdownMenuItem(text = { Text(extra.first) }, onClick = { open = false; extra.second(t) })
                DropdownMenuItem(text = { Text("Retirer de la bibliothèque", color = FC.Red) }, onClick = { open = false; menu.onRemove(t) })
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, color = FC.Gold, fontSize = 16.sp, modifier = modifier.padding(horizontal = 12.dp, vertical = 8.dp))
}

@Composable
fun EmptyHint(text: String) {
    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = FC.Silver, fontSize = 14.sp)
    }
}

@OptIn(UnstableApi::class)
@Composable
fun MiniPlayer(onOpen: (Boolean) -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    val t = st.track ?: return
    Column(Modifier.fillMaxWidth().background(FC.Surface2)) {
        LinearProgressIndicator(
            progress = { if (st.dur > 0) (st.pos.toFloat() / st.dur).coerceIn(0f, 1f) else 0f },
            modifier = Modifier.fillMaxWidth().height(2.dp), color = FC.Green, trackColor = FC.Surface
        )
        Row(Modifier.fillMaxWidth().clickable { onOpen(t.isVideo) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            ArtImage(t.uri, t.isVideo, Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = FC.Silver)
            }
            IconButton(onClick = { pm.togglePlay() }) {
                Icon(if (st.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture", tint = FC.Green, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = { pm.next() }) { Icon(Icons.Filled.SkipNext, "Suivant", tint = FC.Silver) }
        }
    }
}

/** Sélecteurs de fichiers Android (SAF) : un dossier entier, ou des fichiers choisis. */
@Composable
fun rememberLibraryPickers(vm: LibraryViewModel): Pair<() -> Unit, () -> Unit> {
    val tree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u: Uri? -> if (u != null) vm.scanTree(u) }
    val files = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l: List<Uri> -> if (l.isNotEmpty()) vm.addFiles(l) }
    return Pair({ tree.launch(null) }, { files.launch(arrayOf("audio/*", "video/*", "application/ogg")) })
}

@Composable
fun RoundIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(FC.Surface2).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { content() }
}
