package com.djfusion.player.ui.dj

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.djfusion.player.domain.DeckState
import com.djfusion.player.ui.theme.FC
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** Potentiomètre rotatif : glisser verticalement, double-tap = valeur neutre (0). Plage [-1, 1]. */
@Composable
fun Knob(label: String, value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier, knobSize: Dp = 36.dp) {
    val cb by rememberUpdatedState(onChange)
    val v by rememberUpdatedState(value)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier.size(knobSize)
                .pointerInput(Unit) { detectVerticalDragGestures { change, dy -> change.consume(); cb((v - dy / 150f).coerceIn(-1f, 1f)) } }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { cb(0f) }) }
        ) {
            val r = size.minDimension / 2f
            drawCircle(Color(0xFF2A2A2A), r)
            drawCircle(FC.Gold, r, style = Stroke(1.5.dp.toPx()))
            drawCircle(Brush.sweepGradient(listOf(FC.Silver, Color(0xFF6E6E6E), FC.Silver, Color(0xFF6E6E6E), FC.Silver), center), r * 0.8f)
            val theta = Math.toRadians((-135.0 + 270.0 * (v + 1f) / 2f))
            val len = r * 0.75f
            drawLine(
                FC.Gold, Offset(center.x + (sin(theta) * r * 0.25).toFloat(), center.y - (cos(theta) * r * 0.25).toFloat()),
                Offset(center.x + (sin(theta) * len).toFloat(), center.y - (cos(theta) * len).toFloat()),
                strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round
            )
        }
        Text(label, fontSize = 9.sp, color = FC.Silver, textAlign = TextAlign.Center)
    }
}

/** Fader horizontal ou vertical, valeur normalisée [0, 1], double-tap = valeur neutre. */
@Composable
fun Fader(value: Float, onChange: (Float) -> Unit, vertical: Boolean, modifier: Modifier = Modifier, neutral: Float? = null) {
    val cb by rememberUpdatedState(onChange)
    Canvas(
        modifier
            .pointerInput(vertical) {
                fun frac(o: Offset) = (if (vertical) 1f - o.y / size.height else o.x / size.width).coerceIn(0f, 1f)
                detectDragGestures(onDragStart = { cb(frac(it)) }) { c, _ -> c.consume(); cb(frac(c.position)) }
            }
            .pointerInput(Unit) { detectTapGestures(onDoubleTap = { neutral?.let { n -> cb(n) } }) }
    ) {
        val hw = 22.dp.toPx(); val hh = 12.dp.toPx()
        if (vertical) {
            drawRoundRect(Color(0xFF050505), Offset(size.width / 2 - 2.dp.toPx(), 0f), Size(4.dp.toPx(), size.height), CornerRadius(2.dp.toPx()))
            for (i in 0..10) drawLine(Color(0xFF555555), Offset(size.width / 2 + 6.dp.toPx(), i * (size.height - hh) / 10f + hh / 2), Offset(size.width / 2 + 10.dp.toPx(), i * (size.height - hh) / 10f + hh / 2), 1f)
            val y = (1f - value) * (size.height - hh)
            drawRoundRect(FC.Silver, Offset(size.width / 2 - hw / 2, y), Size(hw, hh), CornerRadius(2.dp.toPx()))
            drawLine(FC.Gold, Offset(size.width / 2 - hw / 2, y + hh / 2), Offset(size.width / 2 + hw / 2, y + hh / 2), 2.dp.toPx())
        } else {
            drawRoundRect(Color(0xFF050505), Offset(0f, size.height / 2 - 2.dp.toPx()), Size(size.width, 4.dp.toPx()), CornerRadius(2.dp.toPx()))
            for (i in 0..10) drawLine(Color(0xFF555555), Offset(i * (size.width - hh) / 10f + hh / 2, size.height / 2 + 6.dp.toPx()), Offset(i * (size.width - hh) / 10f + hh / 2, size.height / 2 + 10.dp.toPx()), 1f)
            val x = value * (size.width - hh)
            drawRoundRect(FC.Silver, Offset(x, size.height / 2 - hw / 2), Size(hh, hw), CornerRadius(2.dp.toPx()))
            drawLine(FC.Gold, Offset(x + hh / 2, size.height / 2 - hw / 2), Offset(x + hh / 2, size.height / 2 + hw / 2), 2.dp.toPx())
        }
    }
}

/** Forme d'onde : appui/glissement pour naviguer, zone de boucle en vert, hot cues en blanc. */
@Composable
fun WaveformView(s: DeckState, onSeek: (Float) -> Unit, light: Boolean, modifier: Modifier = Modifier) {
    val seek by rememberUpdatedState(onSeek)
    Canvas(
        modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFF101010))
            .pointerInput(Unit) { detectTapGestures { seek(it.x / size.width) } }
            .pointerInput(Unit) { detectHorizontalDragGestures { c, _ -> c.consume(); seek(c.position.x / size.width) } }
    ) {
        val w = size.width; val h = size.height
        val wf = s.waveform
        val prog = if (s.durMs > 0) (s.posMs.toFloat() / s.durMs).coerceIn(0f, 1f) else 0f
        if (wf.isNotEmpty()) {
            val n = wf.size; val bw = w / n; val step = if (light) 2 else 1
            var i = 0
            while (i < n) {
                val ph = wf[i] * h * 0.9f
                val x = i * bw + bw / 2
                drawLine(if (i.toFloat() / n < prog) FC.Gold else Color(0xFF7A6620), Offset(x, (h - ph) / 2), Offset(x, (h + ph) / 2), strokeWidth = (bw * step).coerceAtLeast(1f))
                i += step
            }
        }
        val li = s.loopIn; val lo = s.loopOut
        if (s.durMs > 0 && li != null && lo != null) {
            val a = li.toFloat() / s.durMs * w; val b = lo.toFloat() / s.durMs * w
            drawRect(FC.Green.copy(alpha = if (s.loopActive) 0.35f else 0.15f), Offset(a, 0f), Size((b - a).coerceAtLeast(1f), h))
        }
        if (s.durMs > 0) s.hotCues.values.forEach { drawLine(FC.White, Offset(it.toFloat() / s.durMs * w, 0f), Offset(it.toFloat() / s.durMs * w, h), 1.5.dp.toPx()) }
        drawLine(FC.Green, Offset(prog * w, 0f), Offset(prog * w, h), 2.dp.toPx())
    }
}

/** Jog wheel : anneau doré, disque argenté, rotation liée à la lecture ; glisser = scratch / nudge. */
@Composable
fun JogWheel(rotation: Float, playing: Boolean, onJog: (Float) -> Unit, onEnd: () -> Unit, modifier: Modifier = Modifier) {
    val jog by rememberUpdatedState(onJog)
    val end by rememberUpdatedState(onEnd)
    var extra by remember { mutableFloatStateOf(0f) }
    Canvas(
        modifier.pointerInput(Unit) {
            var last = 0f
            detectDragGestures(
                onDragStart = { o -> last = atan2(o.y - size.height / 2f, o.x - size.width / 2f) },
                onDragEnd = { end() }, onDragCancel = { end() }
            ) { c, _ ->
                c.consume()
                val a = atan2(c.position.y - size.height / 2f, c.position.x - size.width / 2f)
                var d = Math.toDegrees((a - last).toDouble()).toFloat()
                if (d > 180f) d -= 360f
                if (d < -180f) d += 360f
                last = a
                extra += d
                jog(d)
            }
        }
    ) {
        val r = size.minDimension / 2f
        drawCircle(Color(0xFF151515), r)
        drawCircle(FC.Gold, r - 3.dp.toPx(), style = Stroke(6.dp.toPx()))
        if (playing) drawCircle(FC.Green.copy(alpha = 0.5f), r - 9.5.dp.toPx(), style = Stroke(1.5.dp.toPx()))
        drawCircle(Brush.sweepGradient(listOf(FC.Silver, Color(0xFF787878), FC.Silver, Color(0xFF787878), FC.Silver), center), r * 0.78f)
        rotate(rotation + extra, center) {
            for (i in 0 until 4) {
                rotate(i * 90f, center) { drawLine(Color(0xFF9A9A9A), Offset(center.x, center.y - r * 0.74f), Offset(center.x, center.y - r * 0.5f), 1.5.dp.toPx()) }
            }
            drawCircle(Color(0xFF111111), r * 0.3f)
            drawCircle(FC.Gold, r * 0.3f, style = Stroke(1.5.dp.toPx()))
            drawLine(FC.Gold, Offset(center.x, center.y - r * 0.68f), Offset(center.x, center.y - r * 0.32f), 3.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
fun PadButton(label: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.height(24.dp).clip(RoundedCornerShape(4.dp))
            .background(if (active) FC.Green.copy(alpha = 0.25f) else FC.Surface2)
            .border(1.dp, if (active) FC.Green else Color(0xFF3A3A3A), RoundedCornerShape(4.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 10.sp, color = if (active) FC.Green else FC.White, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun HoldPad(label: String, modifier: Modifier = Modifier, onDown: () -> Unit, onUp: () -> Unit) {
    val d by rememberUpdatedState(onDown)
    val u by rememberUpdatedState(onUp)
    Box(
        modifier.height(24.dp).clip(RoundedCornerShape(4.dp)).background(FC.Surface2)
            .border(1.dp, Color(0xFF3A3A3A), RoundedCornerShape(4.dp))
            .pointerInput(Unit) { detectTapGestures(onPress = { d(); tryAwaitRelease(); u() }) },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 10.sp, color = FC.White, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun PlayButton(playing: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF141414))
            .border(3.dp, if (playing) FC.Green else Color(0xFF2E7D4F), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture/Pause", tint = FC.White, modifier = Modifier.size(28.dp)) }
}

@Composable
fun CueButton(onPress: () -> Unit, onRelease: () -> Unit) {
    val p by rememberUpdatedState(onPress)
    val r by rememberUpdatedState(onRelease)
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF141414)).border(3.dp, FC.Gold, CircleShape)
            .pointerInput(Unit) { detectTapGestures(onPress = { p(); tryAwaitRelease(); r() }) },
        contentAlignment = Alignment.Center
    ) { Text("CUE", color = FC.White, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HotCuePad(n: Int, set: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    Box(
        modifier.aspectRatio(1f).clip(RoundedCornerShape(5.dp))
            .background(if (set) FC.Gold.copy(alpha = 0.3f) else FC.Surface2)
            .border(1.5.dp, if (set) FC.Gold else Color(0xFF3A3A3A), RoundedCornerShape(5.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLong),
        contentAlignment = Alignment.Center
    ) { Text("$n", color = if (set) FC.Gold else FC.Silver, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
}
