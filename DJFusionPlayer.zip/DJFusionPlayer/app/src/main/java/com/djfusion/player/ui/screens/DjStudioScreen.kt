@file:OptIn(ExperimentalFoundationApi::class)

package com.djfusion.player.ui.screens

import android.content.pm.ActivityInfo
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.djengine.Deck
import com.djfusion.player.djengine.DjEngine
import com.djfusion.player.domain.fmtTime
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.components.ArtImage
import com.djfusion.player.ui.components.findActivity
import com.djfusion.player.ui.dj.*
import com.djfusion.player.ui.theme.FC

@OptIn(UnstableApi::class)
@Composable
fun DjStudioScreen(vm: LibraryViewModel, onBack: () -> Unit, onHotCues: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val dj = ctx.container.dj
    val pm = ctx.container.player

    DisposableEffect(Unit) {
        pm.player.pause()
        val act = ctx.findActivity()
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val win = act?.window
        val ctrl = win?.let { WindowCompat.getInsetsController(it, view) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    var picker by remember { mutableStateOf<Int?>(null) }
    val light by dj.light.collectAsState()
    val smart by dj.smartMix.collectAsState()
    val advice by dj.advice.collectAsState()

    Column(Modifier.fillMaxSize().background(FC.Bg).displayCutoutPadding()) {
        Row(Modifier.fillMaxWidth().height(34.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(32.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Fermer", tint = FC.Silver, modifier = Modifier.size(18.dp))
            }
            Text("DJ FUSION", color = FC.Gold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.width(8.dp))
            Text(
                if (smart) "Smart Mix : $advice" else advice,
                color = FC.Silver, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            SmallChip("Smart Mix", smart) { dj.setSmartMix(!smart) }
            Spacer(Modifier.width(4.dp))
            SmallChip("Léger", light) { dj.setLightMode(!light) }
            Spacer(Modifier.width(4.dp))
            SmallChip("HOT CUES", false, onHotCues)
        }
        Row(Modifier.fillMaxWidth().weight(1f)) {
            DeckPanel(dj.decks[0], { picker = 0 }, light, Modifier.weight(1f).fillMaxHeight())
            Mixer(dj, Modifier.width(196.dp).fillMaxHeight())
            DeckPanel(dj.decks[1], { picker = 1 }, light, Modifier.weight(1f).fillMaxHeight())
        }
    }

    picker?.let { i ->
        TrackPickerDialog(vm, onPick = { t -> dj.decks[i].load(t); picker = null }, onDismiss = { picker = null })
    }
}

@Composable
private fun SmallChip(label: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(24.dp).clip4().background(if (active) FC.Green.copy(alpha = 0.25f) else FC.Surface2)
            .border(1.dp, if (active) FC.Green else Color(0xFF3A3A3A), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 10.sp, color = if (active) FC.Green else FC.White) }
}

private fun Modifier.clip4() = this.then(Modifier.clip(RoundedCornerShape(12.dp)))

@OptIn(UnstableApi::class)
@Composable
fun DeckPanel(deck: Deck, onLoad: () -> Unit, light: Boolean, modifier: Modifier = Modifier) {
    val s by deck.state.collectAsState()
    BoxWithConstraints(modifier.background(Color(0xFF111111)).padding(4.dp)) {
        val jog = (maxHeight - 200.dp).coerceIn(84.dp, 150.dp)
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            // En-tête : platine, titre, temps
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(22.dp).background(FC.Gold, RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Text(deck.name, color = Color.Black, fontSize = 12.sp)
                }
                IconButton(onClick = onLoad, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Filled.FolderOpen, "Charger", tint = FC.Silver, modifier = Modifier.size(18.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text(s.track?.title ?: "Charger une piste", fontSize = 12.sp, maxLines = 1, modifier = Modifier.basicMarquee())
                    Text(s.track?.artist ?: "—", fontSize = 10.sp, color = FC.Silver, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text("${fmtTime(s.posMs)}/${fmtTime(s.durMs)}", fontSize = 11.sp, color = FC.Green, fontFamily = FontFamily.Monospace)
            }
            WaveformView(s, { deck.seekFraction(it) }, light, Modifier.fillMaxWidth().height(42.dp))
            Row(Modifier.fillMaxWidth().height(jog), verticalAlignment = Alignment.CenterVertically) {
                JogWheel((s.posMs / 1000f) * 200f, s.playing, { deck.jog(it) }, { deck.jogEnd() }, Modifier.size(jog))
                Column(Modifier.weight(1f).padding(start = 6.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        PadButton("IN", Modifier.weight(1f)) { deck.loopIn() }
                        PadButton("OUT", Modifier.weight(1f)) { deck.loopOut() }
                        PadButton("↻", Modifier.weight(1f), s.loopActive) { deck.toggleLoop() }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        listOf(0.5f to "½", 1f to "1", 2f to "2", 4f to "4", 8f to "8").forEach { (b, l) ->
                            PadButton(l, Modifier.weight(1f)) { deck.autoLoop(b) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        HoldPad("◀ BEND", Modifier.weight(1f), { deck.bend(-1) }, { deck.bend(0) })
                        HoldPad("BEND ▶", Modifier.weight(1f), { deck.bend(1) }, { deck.bend(0) })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        PadButton("KEY LOCK", Modifier.weight(1f), s.keyLock) { deck.toggleKeyLock() }
                        PadButton("TAP ${s.bpm.toInt()}", Modifier.weight(1f)) { deck.tapBpm() }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().height(24.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("TEMPO", fontSize = 9.sp, color = FC.Silver)
                Fader(
                    s.tempo + 0.5f,
                    { v -> deck.setTempo(if (kotlin.math.abs(v - 0.5f) < 0.012f) 0f else v - 0.5f) },
                    false, Modifier.weight(1f).fillMaxHeight().padding(horizontal = 6.dp), neutral = 0.5f
                )
                Text("%+.1f%%".format(s.tempo * 100), fontSize = 10.sp, color = FC.Green, fontFamily = FontFamily.Monospace)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PlayButton(s.playing) { deck.playPause() }
                CueButton({ deck.cuePress() }, { deck.cueRelease() })
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (slot in 1..4) {
                        HotCuePad(slot, s.hotCues.containsKey(slot), Modifier.weight(1f), { deck.hotCue(slot) }, { deck.deleteHotCue(slot) })
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun Mixer(dj: DjEngine, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val a by dj.decks[0].state.collectAsState()
    val b by dj.decks[1].state.collectAsState()
    val cross by dj.cross.collectAsState()
    val fade by dj.autoFadeSec.collectAsState()

    @Composable
    fun KnobColumn(i: Int, s: com.djfusion.player.domain.DeckState) {
        val d = dj.decks[i]
        Column(Modifier.width(46.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally) {
            Knob("HIGH", s.high, { d.setHigh(it) })
            Knob("MID", s.mid, { d.setMid(it) })
            Knob("LOW", s.low, { d.setLow(it) })
            Knob("FILTER", s.filter, { d.setFilter(it) })
        }
    }

    Column(modifier.background(Color(0xFF0E0E0E)).verticalScroll(rememberScrollState()).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().height(200.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            KnobColumn(0, a)
            Column(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("VOLUME", fontSize = 8.sp, color = FC.Gold)
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Fader(a.volume, { dj.decks[0].setVolume(it) }, true, Modifier.width(28.dp).fillMaxHeight().padding(vertical = 4.dp), neutral = 1f)
                    Fader(b.volume, { dj.decks[1].setVolume(it) }, true, Modifier.width(28.dp).fillMaxHeight().padding(vertical = 4.dp), neutral = 1f)
                }
            }
            KnobColumn(1, b)
        }
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            PreCueButton(a.preCue) { if (!dj.togglePreCue(0)) Toast.makeText(ctx, "Aucun casque détecté", Toast.LENGTH_SHORT).show() }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                PadButton("AUTO FADE", Modifier.width(78.dp)) { dj.autoFade(if (cross < 0f) 1 else 0) }
                Spacer(Modifier.height(2.dp))
                PadButton("${fade}s", Modifier.width(40.dp)) {
                    val opts = listOf(2, 3, 5, 8, 12)
                    dj.setFadeSec(opts[(opts.indexOf(fade) + 1).mod(opts.size)])
                }
            }
            PreCueButton(b.preCue) { if (!dj.togglePreCue(1)) Toast.makeText(ctx, "Aucun casque détecté", Toast.LENGTH_SHORT).show() }
        }
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("A", color = FC.Gold, fontSize = 12.sp)
            Fader((cross + 1f) / 2f, { dj.setCross(it * 2f - 1f) }, false, Modifier.weight(1f).height(34.dp).padding(horizontal = 4.dp), neutral = 0.5f)
            Text("B", color = FC.Gold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun PreCueButton(active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).background(if (active) FC.Green.copy(alpha = 0.25f) else FC.Surface2, RoundedCornerShape(15.dp))
            .border(1.5.dp, if (active) FC.Green else FC.Gold, RoundedCornerShape(15.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.Headphones, "Pré-écoute", tint = if (active) FC.Green else FC.Gold, modifier = Modifier.size(16.dp)) }
}

/** Sélection de piste pour une platine (recherche locale dans la bibliothèque). */
@Composable
fun TrackPickerDialog(vm: LibraryViewModel, onPick: (TrackEntity) -> Unit, onDismiss: () -> Unit) {
    val songs by vm.songs.collectAsState()
    var q by remember { mutableStateOf("") }
    val list = remember(songs, q) {
        if (q.isBlank()) songs else songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.6f).fillMaxHeight(0.92f), shape = RoundedCornerShape(12.dp), color = FC.Surface) {
            Column(Modifier.padding(8.dp)) {
                OutlinedTextField(
                    q, { q = it }, singleLine = true, label = { Text("Rechercher une piste") },
                    modifier = Modifier.fillMaxWidth()
                )
                if (songs.isEmpty()) {
                    Text("Bibliothèque vide : ajoutez des fichiers depuis l'écran Bibliothèque.", color = FC.Silver, modifier = Modifier.padding(16.dp))
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(list, key = { it.id }) { t ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(t) }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            ArtImage(t.uri, false, Modifier.size(36.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                                Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = FC.Silver)
                            }
                            Text(fmtTime(t.durationMs), fontSize = 11.sp, color = FC.Silver)
                        }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Fermer") }
            }
        }
    }
}

/** Gestion des HOT CUES des deux platines : définir, aller, ajuster ±0,1 s, supprimer. */
@OptIn(UnstableApi::class)
@Composable
fun HotCueScreen(onBack: () -> Unit) {
    val dj = LocalContext.current.container.dj
    Column(Modifier.fillMaxSize().background(FC.Bg).statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text("Gestion des HOT CUES", color = FC.Gold, fontSize = 18.sp)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(dj.decks) { d ->
                val s by d.state.collectAsState()
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("Platine ${d.name} — ${s.track?.title ?: "aucune piste"}", color = FC.White, fontSize = 15.sp)
                    if (s.track == null) Text("Chargez une piste dans le studio.", color = FC.Silver, fontSize = 12.sp)
                    else for (slot in 1..4) {
                        val c = s.hotCues[slot]
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("HOT CUE $slot", color = FC.Gold, modifier = Modifier.width(92.dp), fontSize = 12.sp)
                            Text(c?.let { fmtTime(it) } ?: "—", color = FC.Green, modifier = Modifier.width(52.dp), fontFamily = FontFamily.Monospace)
                            TextButton(onClick = { d.setHotCueHere(slot) }) { Text("Ici", fontSize = 11.sp) }
                            TextButton(onClick = { d.jumpHotCue(slot) }, enabled = c != null) { Text("Aller", fontSize = 11.sp) }
                            TextButton(onClick = { d.nudgeHotCue(slot, -100) }, enabled = c != null) { Text("−0,1", fontSize = 11.sp) }
                            TextButton(onClick = { d.nudgeHotCue(slot, 100) }, enabled = c != null) { Text("+0,1", fontSize = 11.sp) }
                            TextButton(onClick = { d.deleteHotCue(slot) }, enabled = c != null) { Text("Suppr.", fontSize = 11.sp, color = FC.Red) }
                        }
                    }
                }
            }
        }
    }
}
