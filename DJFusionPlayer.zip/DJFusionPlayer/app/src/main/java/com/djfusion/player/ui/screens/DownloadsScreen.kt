package com.djfusion.player.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.work.WorkInfo
import com.djfusion.player.ui.DownloadViewModel
import com.djfusion.player.ui.SettingsViewModel
import com.djfusion.player.ui.components.SectionTitle
import com.djfusion.player.ui.theme.FC

@OptIn(UnstableApi::class)
@Composable
fun DownloadsScreen() {
    val vm: DownloadViewModel = viewModel()
    val sv: SettingsViewModel = viewModel()
    val works by vm.works.collectAsState(emptyList())
    val prefs by sv.prefs.collectAsState()
    var url by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val folder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u: Uri? -> if (u != null) vm.setTree(u) }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Téléchargements", color = FC.Gold, fontSize = 22.sp) }
        item {
            OutlinedTextField(url, { url = it; error = null }, label = { Text("URL directe (https://…)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), isError = error != null)
            OutlinedTextField(name, { name = it }, label = { Text("Nom du fichier (optionnel)") }, singleLine = true, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            error?.let { Text(it, color = FC.Red, fontSize = 12.sp) }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    error = vm.enqueue(url, name)
                    if (error == null) { url = ""; name = "" }
                }, colors = ButtonDefaults.buttonColors(containerColor = FC.Gold)) { Icon(Icons.Filled.Download, null); Spacer(Modifier.width(6.dp)); Text("Télécharger") }
                OutlinedButton(onClick = { vm.clearFinished() }) { Text("Vider l'historique") }
            }
            Text(
                "Destination : " + (if (prefs.dlTree == null) "Download/DJ Fusion Player" else "dossier personnalisé"),
                color = FC.Silver, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
            Row {
                TextButton(onClick = { folder.launch(null) }) { Text("Choisir un dossier (SAF)") }
                if (prefs.dlTree != null) TextButton(onClick = { vm.setTree(null) }) { Text("Dossier par défaut") }
            }
        }
        item { SectionTitle("File d'attente", Modifier.padding(0.dp)) }
        if (works.isEmpty()) item { Text("Aucun téléchargement.", color = FC.Silver) }
        items(works.sortedByDescending { it.state == WorkInfo.State.RUNNING }, key = { it.id }) { w ->
            val n = w.tags.firstOrNull { it.startsWith("n:") }?.removePrefix("n:") ?: "fichier"
            val p = w.progress.getInt("p", 0)
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(FC.Surface).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(n, maxLines = 1, fontSize = 14.sp)
                        val label = when (w.state) {
                            WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED -> "En attente"
                            WorkInfo.State.RUNNING -> if (p >= 0) "$p %" else "En cours…"
                            WorkInfo.State.SUCCEEDED -> "Terminé — ajouté à la bibliothèque"
                            WorkInfo.State.FAILED -> "Échec : " + (w.outputData.getString("error") ?: "erreur")
                            WorkInfo.State.CANCELLED -> "Annulé"
                        }
                        Text(label, fontSize = 12.sp, color = when (w.state) {
                            WorkInfo.State.SUCCEEDED -> FC.Green
                            WorkInfo.State.FAILED -> FC.Red
                            else -> FC.Silver
                        })
                    }
                    if (!w.state.isFinished) IconButton(onClick = { vm.cancel(w.id) }) { Icon(Icons.Filled.Close, "Annuler", tint = FC.Red) }
                }
                if (w.state == WorkInfo.State.RUNNING) {
                    if (p >= 0) LinearProgressIndicator(progress = { p / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = FC.Green)
                    else LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 6.dp), color = FC.Green)
                }
            }
        }
    }
}
