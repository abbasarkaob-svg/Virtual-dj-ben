package com.djfusion.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.components.*
import com.djfusion.player.ui.theme.FC

@OptIn(UnstableApi::class)
@Composable
fun HomeScreen(vm: LibraryViewModel, menu: TrackMenu, onNav: (String) -> Unit, onPlayed: (Boolean) -> Unit) {
    val pm = LocalContext.current.container.player
    val count by vm.count.collectAsState()
    val recent by vm.recent.collectAsState()
    val favs by vm.favorites.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val scanned by vm.scanned.collectAsState()
    val st by pm.state.collectAsState()
    val (pickFolder, pickFiles) = rememberLibraryPickers(vm)

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DJ Fusion Player", color = FC.Gold, fontSize = 24.sp)
                    Text("Lecteur multimédia & studio DJ", color = FC.Silver, fontSize = 12.sp)
                }
                IconButton(onClick = { onNav("settings") }) { Icon(Icons.Filled.Settings, "Paramètres", tint = FC.Silver) }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureCard("Studio DJ", Icons.Filled.Album, Modifier.weight(1f)) { onNav("dj") }
                    FeatureCard("Découverte", Icons.Filled.Explore, Modifier.weight(1f)) { onNav("discovery") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeatureCard("Playlists", Icons.Filled.QueueMusic, Modifier.weight(1f)) { onNav("playlists") }
                    FeatureCard("Téléchargements", Icons.Filled.Download, Modifier.weight(1f)) { onNav("downloads") }
                }
            }
        }
        if (st.track != null) {
            item {
                SectionTitle("Reprendre la lecture")
                val t = st.track!!
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(10.dp)).background(FC.Surface)
                        .clickable { pm.togglePlay(); onPlayed(t.isVideo) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtImage(t.uri, t.isVideo, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, fontSize = 15.sp)
                        Text("${t.artist} • ${fmtPos(st.pos)} / ${fmtPos(st.dur)}", color = FC.Silver, fontSize = 12.sp, maxLines = 1)
                    }
                    Icon(Icons.Filled.PlayCircle, null, tint = FC.Green, modifier = Modifier.size(36.dp))
                }
            }
        }
        item {
            SectionTitle("Bibliothèque ($count éléments)")
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = pickFolder) { Icon(Icons.Filled.FolderOpen, null); Spacer(Modifier.width(6.dp)); Text("Dossier") }
                OutlinedButton(onClick = pickFiles) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Fichiers") }
            }
            if (scanning) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 12.dp), color = FC.Green)
                Text("Indexation… $scanned fichiers", color = FC.Silver, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
            }
            if (count == 0 && !scanning) EmptyHint("Ajoutez un dossier ou des fichiers pour commencer.")
        }
        if (recent.isNotEmpty()) {
            item { SectionTitle("Historique") }
            items(recent.take(8), key = { "r${it.id}" }) { t ->
                TrackRow(t, menu, st.track?.id == t.id) { pm.play(recent, recent.indexOf(t)); onPlayed(t.isVideo) }
            }
        }
        if (favs.isNotEmpty()) {
            item { SectionTitle("Favoris") }
            items(favs.take(8), key = { "f${it.id}" }) { t ->
                TrackRow(t, menu, st.track?.id == t.id) { pm.play(favs, favs.indexOf(t)); onPlayed(t.isVideo) }
            }
        }
    }
}

private fun fmtPos(ms: Long) = com.djfusion.player.domain.fmtTime(ms)

@Composable
private fun FeatureCard(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(64.dp).clip(RoundedCornerShape(12.dp)).background(FC.Surface)
            .border(1.dp, FC.Gold.copy(alpha = 0.6f), RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = FC.Gold, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 14.sp)
    }
}
