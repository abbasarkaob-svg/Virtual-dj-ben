package com.djfusion.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.data.PlaylistEntity
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.components.*
import com.djfusion.player.ui.theme.FC

private val TABS = listOf("Chansons", "Vidéos", "Dossiers", "Artistes", "Albums", "Playlists", "Favoris")

@OptIn(UnstableApi::class, ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(vm: LibraryViewModel, menu: TrackMenu, onPlayed: (Boolean) -> Unit, onPlaylist: (Long) -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val songs by vm.songs.collectAsState()
    val videos by vm.videos.collectAsState()
    val favs by vm.favorites.collectAsState()
    val playlists by vm.playlists.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val (pickFolder, pickFiles) = rememberLibraryPickers(vm)
    var newPl by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Bibliothèque", color = FC.Gold, fontSize = 22.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = pickFolder) { Icon(Icons.Filled.FolderOpen, "Ajouter un dossier", tint = FC.Silver) }
            IconButton(onClick = pickFiles) { Icon(Icons.Filled.Add, "Ajouter des fichiers", tint = FC.Silver) }
        }
        if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth(), color = FC.Green)
        ScrollableTabRow(selectedTabIndex = tab, containerColor = FC.Bg, contentColor = FC.Gold, edgePadding = 8.dp) {
            TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t, fontSize = 13.sp) }) }
        }
        fun play(list: List<TrackEntity>, t: TrackEntity) { pm.play(list, list.indexOf(t)); onPlayed(t.isVideo) }
        when (tab) {
            0 -> FlatList(songs, menu, st.track?.id, "Aucune chanson indexée.") { play(songs, it) }
            1 -> FlatList(videos, menu, st.track?.id, "Aucune vidéo indexée.") { play(videos, it) }
            2 -> GroupedTracks(songs + videos, { it.folder }, menu, st.track?.id) { l, t -> play(l, t) }
            3 -> GroupedTracks(songs, { it.artist }, menu, st.track?.id) { l, t -> play(l, t) }
            4 -> GroupedTracks(songs, { it.album }, menu, st.track?.id) { l, t -> play(l, t) }
            5 -> LazyColumn(Modifier.fillMaxSize()) {
                item { TextButton(onClick = { newPl = true }, modifier = Modifier.padding(8.dp)) { Icon(Icons.Filled.Add, null); Spacer(Modifier.width(6.dp)); Text("Nouvelle playlist") } }
                items(playlists, key = { it.id }) { p -> PlaylistRow(p) { onPlaylist(p.id) } }
                if (playlists.isEmpty()) item { EmptyHint("Aucune playlist.") }
            }
            else -> FlatList(favs, menu, st.track?.id, "Aucun favori pour le moment.") { play(favs, it) }
        }
    }
    if (newPl) NameDialog("Nouvelle playlist", { newPl = false }) { vm.createPlaylist(it); newPl = false }
}

@Composable
fun PlaylistRow(p: PlaylistEntity, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.QueueMusic, null, tint = FC.Gold)
        Spacer(Modifier.width(14.dp))
        Text(p.name, fontSize = 16.sp)
    }
}

@Composable
fun FlatList(list: List<TrackEntity>, menu: TrackMenu, playingId: Long?, empty: String, onClick: (TrackEntity) -> Unit) {
    if (list.isEmpty()) { EmptyHint(empty); return }
    LazyColumn(Modifier.fillMaxSize()) {
        items(list, key = { it.id }) { t -> TrackRow(t, menu, playingId == t.id) { onClick(t) } }
    }
}

@Composable
fun GroupedTracks(list: List<TrackEntity>, key: (TrackEntity) -> String, menu: TrackMenu, playingId: Long?, onPlay: (List<TrackEntity>, TrackEntity) -> Unit) {
    if (list.isEmpty()) { EmptyHint("Rien à afficher pour le moment."); return }
    val groups = remember(list) { list.groupBy(key).entries.sortedBy { it.key.lowercase() } }
    var open by remember { mutableStateOf(setOf<String>()) }
    LazyColumn(Modifier.fillMaxSize()) {
        groups.forEach { (k, tracks) ->
            item(key = "g$k") {
                Row(
                    Modifier.fillMaxWidth().background(FC.Surface).clickable { open = if (k in open) open - k else open + k }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(if (k in open) Icons.Filled.ExpandMore else Icons.Filled.ChevronRight, null, tint = FC.Gold)
                    Spacer(Modifier.width(8.dp))
                    Text(k, Modifier.weight(1f), maxLines = 1, fontSize = 15.sp)
                    Text("${tracks.size}", color = FC.Silver)
                }
            }
            if (k in open) items(tracks, key = { "t${it.id}" }) { t -> TrackRow(t, menu, playingId == t.id) { onPlay(tracks, t) } }
        }
    }
}

@Composable
fun NameDialog(title: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, label = { Text("Nom") }) },
        confirmButton = { TextButton(onClick = { if (v.isNotBlank()) onOk(v) }) { Text("Créer") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@OptIn(UnstableApi::class)
@Composable
fun SearchScreen(vm: LibraryViewModel, menu: TrackMenu, onPlayed: (Boolean) -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    val q by vm.query.collectAsState()
    val res by vm.results.collectAsState()
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        OutlinedTextField(
            q, { vm.query.value = it }, singleLine = true, label = { Text("Titre, artiste, album…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        )
        if (q.isNotBlank() && res.isEmpty()) EmptyHint("Aucun résultat.")
        FlatList(res, menu, st.track?.id, "") { t -> pm.play(res, res.indexOf(t)); onPlayed(t.isVideo) }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlaylistsScreen(vm: LibraryViewModel, onBack: () -> Unit, onPlaylist: (Long) -> Unit) {
    val playlists by vm.playlists.collectAsState()
    var newPl by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text("Playlists", color = FC.Gold, fontSize = 22.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { newPl = true }) { Icon(Icons.Filled.Add, "Nouvelle", tint = FC.Silver) }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(playlists, key = { it.id }) { p -> PlaylistRow(p) { onPlaylist(p.id) } }
            if (playlists.isEmpty()) item { EmptyHint("Aucune playlist. Créez-en une avec +.") }
        }
    }
    if (newPl) NameDialog("Nouvelle playlist", { newPl = false }) { vm.createPlaylist(it); newPl = false }
}

@OptIn(UnstableApi::class)
@Composable
fun PlaylistDetailScreen(id: Long, vm: LibraryViewModel, menu: TrackMenu, onBack: () -> Unit, onPlayed: (Boolean) -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    val pl by vm.playlist(id).collectAsState(null)
    val tracks by vm.playlistTracks(id).collectAsState(emptyList())
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text(pl?.name ?: "Playlist", color = FC.Gold, fontSize = 22.sp, modifier = Modifier.weight(1f), maxLines = 1)
            IconButton(onClick = { if (tracks.isNotEmpty()) { pm.play(tracks, 0); onPlayed(tracks[0].isVideo) } }) {
                Icon(Icons.Filled.PlayCircle, "Tout lire", tint = FC.Green)
            }
            IconButton(onClick = { vm.deletePlaylist(id); onBack() }) { Icon(Icons.Filled.Delete, "Supprimer la playlist", tint = FC.Red) }
        }
        if (tracks.isEmpty()) EmptyHint("Playlist vide : utilisez ⋮ › Ajouter à une playlist.")
        LazyColumn(Modifier.fillMaxSize()) {
            items(tracks, key = { it.id }) { t ->
                TrackRow(t, menu, st.track?.id == t.id, extra = "Retirer de la playlist" to { x -> vm.removeFromPlaylist(id, x) }) {
                    pm.play(tracks, tracks.indexOf(t)); onPlayed(t.isVideo)
                }
            }
        }
    }
}
