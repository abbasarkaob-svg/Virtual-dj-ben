package com.djfusion.player.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.data.TrackEntity
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.SettingsViewModel
import com.djfusion.player.ui.components.*
import com.djfusion.player.ui.theme.FC

/** Découverte hors-ligne : genres et similarités calculés uniquement à partir des métadonnées locales. */
@OptIn(UnstableApi::class)
@Composable
fun DiscoveryScreen(vm: LibraryViewModel, menu: TrackMenu, onBack: () -> Unit, onPlayed: (Boolean) -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    val genres by vm.genres.collectAsState()
    var genre by remember { mutableStateOf<String?>(null) }
    val inGenre by (genre?.let { vm.byGenre(it) } ?: kotlinx.coroutines.flow.flowOf(emptyList())).collectAsState(emptyList())
    val cur = st.track
    val similar by produceState(emptyList<TrackEntity>(), cur?.id) { value = if (cur != null && !cur.isVideo) vm.similar(cur) else emptyList() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text("Découverte", color = FC.Gold, fontSize = 22.sp)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                SectionTitle("Genres de votre bibliothèque")
                if (genres.isEmpty()) EmptyHint("Indexez de la musique pour explorer les genres.")
                LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(genres) { g ->
                        FilterChip(selected = genre == g.genre, onClick = { genre = if (genre == g.genre) null else g.genre }, label = { Text("${g.genre} (${g.count})") })
                    }
                }
            }
            if (genre != null) {
                item { SectionTitle("Genre : $genre") }
                items(inGenre, key = { "g${it.id}" }) { t -> TrackRow(t, menu, st.track?.id == t.id) { pm.play(inGenre, inGenre.indexOf(t)); onPlayed(false) } }
            }
            item {
                SectionTitle(if (cur != null) "Similaires à « ${cur.title} »" else "Similaires (lancez une chanson)")
                if (cur != null && similar.isEmpty()) EmptyHint("Aucun titre similaire (même genre ou même artiste).")
            }
            items(similar, key = { "s${it.id}" }) { t -> TrackRow(t, menu, st.track?.id == t.id) { pm.play(similar, similar.indexOf(t)); onPlayed(false) } }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onLicenses: () -> Unit, libVm: LibraryViewModel) {
    val vm: SettingsViewModel = viewModel()
    val p by vm.prefs.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text("Paramètres", color = FC.Gold, fontSize = 22.sp)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            item { SwitchRow("Mode léger", "Réduit les animations (forme d'onde, rotation) sur appareils modestes", p.lightMode) { vm.setLight(it) } }
            item { SwitchRow("Smart Mix", "Suggestions et transitions automatiques basées sur des règles locales (sans IA)", p.smartMix) { vm.setSmart(it) } }
            item {
                Text("Durée du fondu automatique : ${p.fadeSec} s", modifier = Modifier.padding(top = 8.dp))
                Slider(p.fadeSec.toFloat(), { vm.setFade(it.toInt()) }, valueRange = 1f..16f, steps = 14,
                    colors = SliderDefaults.colors(thumbColor = FC.Gold, activeTrackColor = FC.Gold))
            }
            item { OutlinedButton(onClick = { libVm.rescanAll() }, modifier = Modifier.fillMaxWidth()) { Text("Réanalyser les dossiers de la bibliothèque") } }
            item { OutlinedButton(onClick = { vm.clearHistory() }, modifier = Modifier.fillMaxWidth()) { Text("Effacer l'historique de lecture") } }
            item { OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Vider la bibliothèque", color = FC.Red) } }
            item { OutlinedButton(onClick = onLicenses, modifier = Modifier.fillMaxWidth()) { Text("Licences") } }
            item { Text("DJ Fusion Player 1.0.0 — aucune IA, aucun compte, aucune télémétrie. Vos données restent sur l'appareil.", color = FC.Silver, fontSize = 12.sp) }
        }
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, title = { Text("Vider la bibliothèque ?") },
        text = { Text("Les fichiers ne sont pas supprimés de l'appareil, seulement de l'index.") },
        confirmButton = { TextButton(onClick = { libVm.clearLibrary(); confirmClear = false }) { Text("Vider", color = FC.Red) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Annuler") } }
    )
}

@Composable
private fun SwitchRow(title: String, sub: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!v) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title); Text(sub, color = FC.Silver, fontSize = 12.sp) }
        Switch(v, onChange, colors = SwitchDefaults.colors(checkedTrackColor = FC.Green, checkedThumbColor = FC.White))
    }
}

@Composable
fun LicensesScreen(onBack: () -> Unit) {
    val items = listOf(
        "Kotlin & kotlinx.coroutines" to "Apache License 2.0",
        "AndroidX (Core, Lifecycle, Activity, Navigation, DocumentFile)" to "Apache License 2.0",
        "Jetpack Compose & Material 3" to "Apache License 2.0",
        "AndroidX Media3 (ExoPlayer, Session, UI)" to "Apache License 2.0",
        "AndroidX Room, DataStore, WorkManager" to "Apache License 2.0"
    )
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Text("Licences", color = FC.Gold, fontSize = 22.sp)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("DJ Fusion Player n'utilise aucune ressource, marque ni code propriétaire d'une autre application DJ. L'interface est une création originale inspirée d'un agencement classique à deux platines.", color = FC.Silver, fontSize = 13.sp) }
            items(items) { (n, l) -> Column { Text(n, fontSize = 14.sp); Text(l, color = FC.Gold, fontSize = 12.sp) } }
        }
    }
}
