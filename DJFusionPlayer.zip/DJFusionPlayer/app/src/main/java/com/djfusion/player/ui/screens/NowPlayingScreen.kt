package com.djfusion.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import com.djfusion.player.container
import com.djfusion.player.domain.fmtTime
import com.djfusion.player.ui.LibraryViewModel
import com.djfusion.player.ui.components.ArtImage
import com.djfusion.player.ui.theme.FC

@OptIn(UnstableApi::class)
@Composable
fun NowPlayingScreen(vm: LibraryViewModel, onBack: () -> Unit, onAddToPlaylist: () -> Unit) {
    val pm = LocalContext.current.container.player
    val st by pm.state.collectAsState()
    val t = st.track
    val live by (t?.let { vm.observeTrack(it.id) } ?: kotlinx.coroutines.flow.flowOf(null)).collectAsState(null)
    var drag by remember { mutableStateOf<Float?>(null) }
    var vol by remember { mutableFloatStateOf(pm.player.volume) }

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = FC.Silver) }
            Spacer(Modifier.weight(1f))
            Text("EN LECTURE", color = FC.Gold, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onAddToPlaylist) { Icon(Icons.Filled.PlaylistAdd, "Playlist", tint = FC.Silver) }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.weight(1f, fill = false).aspectRatio(1f).fillMaxWidth(0.8f).clip(CircleShape)
                .border(5.dp, FC.Gold, CircleShape).padding(8.dp).clip(CircleShape)
        ) { if (t != null) ArtImage(t.uri, false, Modifier.fillMaxSize()) }
        Spacer(Modifier.height(16.dp))
        Text(t?.title ?: "Aucune lecture", fontSize = 20.sp, maxLines = 2, textAlign = TextAlign.Center)
        Text(t?.artist ?: "", color = FC.Silver, fontSize = 14.sp)
        Spacer(Modifier.height(12.dp))
        val frac = drag ?: if (st.dur > 0) (st.pos.toFloat() / st.dur).coerceIn(0f, 1f) else 0f
        Slider(
            value = frac, onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { pm.seekTo((it * st.dur).toLong()) }; drag = null },
            colors = SliderDefaults.colors(thumbColor = FC.Gold, activeTrackColor = FC.Green)
        )
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime(if (drag != null) (frac * st.dur).toLong() else st.pos), color = FC.Silver, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text(fmtTime(st.dur), color = FC.Silver, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { pm.toggleShuffle() }) { Icon(Icons.Filled.Shuffle, "Aléatoire", tint = if (st.shuffle) FC.Green else FC.Silver) }
            IconButton(onClick = { pm.previous() }) { Icon(Icons.Filled.SkipPrevious, "Précédent", tint = FC.White, modifier = Modifier.size(36.dp)) }
            Box(
                Modifier.size(68.dp).clip(CircleShape).background(FC.Surface).border(3.dp, FC.Green, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = { pm.togglePlay() }, modifier = Modifier.fillMaxSize()) {
                    Icon(if (st.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Lecture", tint = FC.White, modifier = Modifier.size(38.dp))
                }
            }
            IconButton(onClick = { pm.next() }) { Icon(Icons.Filled.SkipNext, "Suivant", tint = FC.White, modifier = Modifier.size(36.dp)) }
            IconButton(onClick = { pm.cycleRepeat() }) {
                Icon(
                    if (st.repeat == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Répéter",
                    tint = if (st.repeat != Player.REPEAT_MODE_OFF) FC.Green else FC.Silver
                )
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { t?.let { x -> vm.toggleFavorite(live ?: x) } }) {
                Icon(if ((live ?: t)?.favorite == true) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favori", tint = FC.Gold)
            }
            Icon(Icons.Filled.VolumeUp, null, tint = FC.Silver)
            Slider(
                vol, { vol = it; pm.setVolume(it) }, modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                colors = SliderDefaults.colors(thumbColor = FC.Silver, activeTrackColor = FC.Silver)
            )
        }
    }
}
