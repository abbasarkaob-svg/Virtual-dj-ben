@file:OptIn(UnstableApi::class)

package com.djfusion.player.ui.screens

import android.content.pm.ActivityInfo
import android.net.Uri
import android.provider.OpenableColumns
import android.view.View
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.djfusion.player.container
import com.djfusion.player.ui.components.findActivity
import com.djfusion.player.ui.theme.FC

@Composable
fun VideoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val pm = ctx.container.player
    val st by pm.state.collectAsState()
    var chrome by remember { mutableStateOf(true) }
    var immersive by remember { mutableStateOf(false) }
    var speedMenu by remember { mutableStateOf(false) }
    var volOpen by remember { mutableStateOf(false) }
    var vol by remember { mutableFloatStateOf(pm.player.volume) }

    val subPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            val name = ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            }
            pm.addSubtitle(u, name)
        }
    }

    // Orientation : suit le format de la vidéo, puis capteur ; restaurée à la sortie.
    DisposableEffect(Unit) {
        val act = ctx.findActivity()
        act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        val l = object : Player.Listener {
            override fun onVideoSizeChanged(v: VideoSize) {
                if (v.width > 0) act?.requestedOrientation =
                    if (v.width >= v.height) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
        pm.player.addListener(l)
        onDispose {
            pm.player.removeListener(l)
            pm.player.pause()
            act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            act?.window?.let { WindowCompat.getInsetsController(it, view).show(WindowInsetsCompat.Type.systemBars()) }
        }
    }

    LaunchedEffect(immersive) {
        ctx.findActivity()?.window?.let { w ->
            val c = WindowCompat.getInsetsController(w, view)
            if (immersive) c.hide(WindowInsetsCompat.Type.systemBars()) else c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    player = pm.player
                    useController = true
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShowSubtitleButton(true)
                    setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v -> chrome = v == View.VISIBLE })
                }
            },
            onRelease = { it.player = null },
            modifier = Modifier.fillMaxSize()
        )
        if (chrome) {
            Row(
                Modifier.fillMaxWidth().background(Color(0x99000000)).statusBarsPadding().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White) }
                Text(st.track?.title ?: "", color = Color.White, maxLines = 1, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Box {
                    TextButton(onClick = { speedMenu = true }) { Icon(Icons.Filled.Speed, null, tint = FC.Gold); Spacer(Modifier.width(4.dp)); Text("${st.speed}x", color = FC.Gold) }
                    DropdownMenu(expanded = speedMenu, onDismissRequest = { speedMenu = false }) {
                        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                            DropdownMenuItem(text = { Text("${s}x") }, onClick = { pm.setSpeed(s); speedMenu = false })
                        }
                    }
                }
                IconButton(onClick = { volOpen = !volOpen }) { Icon(Icons.Filled.VolumeUp, "Volume", tint = Color.White) }
                IconButton(onClick = { subPicker.launch(arrayOf("*/*")) }) { Icon(Icons.Filled.Subtitles, "Sous-titres", tint = Color.White) }
                IconButton(onClick = { immersive = !immersive }) {
                    Icon(if (immersive) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen, "Plein écran", tint = Color.White)
                }
            }
            if (volOpen) {
                Slider(
                    vol, { vol = it; pm.setVolume(it) },
                    modifier = Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top = 56.dp, end = 8.dp).width(180.dp),
                    colors = SliderDefaults.colors(thumbColor = FC.Gold, activeTrackColor = FC.Green)
                )
            }
        }
    }
}
