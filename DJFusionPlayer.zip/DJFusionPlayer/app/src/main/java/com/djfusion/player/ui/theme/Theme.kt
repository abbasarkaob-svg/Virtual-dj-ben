package com.djfusion.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object FC {
    val Bg = Color(0xFF0B0B0B)
    val Surface = Color(0xFF161616)
    val Surface2 = Color(0xFF222222)
    val Gold = Color(0xFFD4AF37)
    val Silver = Color(0xFFC0C0C0)
    val Green = Color(0xFF00E676)
    val Red = Color(0xFFFF5252)
    val White = Color(0xFFFFFFFF)
}

@Composable
fun FusionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FC.Gold, onPrimary = Color.Black,
            secondary = FC.Silver, onSecondary = Color.Black,
            tertiary = FC.Green, background = FC.Bg, onBackground = FC.White,
            surface = FC.Surface, onSurface = FC.White,
            surfaceVariant = FC.Surface2, onSurfaceVariant = FC.Silver,
            error = FC.Red, outline = FC.Gold
        ),
        content = content
    )
}
