# Architecture — DJ Fusion Player

MVVM, 100 % Kotlin / Jetpack Compose, sans IA ni compte. Package `com.djfusion.player`.

| Couche | Rôle |
|---|---|
| `ui/` | Compose : écrans (accueil, bibliothèque, recherche, lecteur audio, lecteur vidéo, studio DJ, HOT CUES, téléchargements, playlists, découverte, paramètres, licences), `ViewModels.kt`, composants DJ (`ui/dj`) |
| `domain/` | Modèles (`DeckState`), règles locales du **Smart Mix** (`SmartMix`) |
| `data/` | Room (`Database.kt`), DataStore (`SettingsStore`), indexation SAF (`MediaRepository`), cache LRU des pochettes (`ArtCache`) |
| `playback/` | `PlayerManager` (ExoPlayer principal, file, aléatoire, répétition, historique, reprise) + `PlaybackService` (MediaSession, notification) |
| `djengine/` | `Deck` (1 ExoPlayer par platine), `DeckFx` (EQ 3 bandes + filtre DJ, `AudioProcessor` biquad temps réel), `DjEngine` (crossfader puissance constante, fondu auto, Smart Mix, pré-écoute casque), `WaveformExtractor` |
| `download/` | `DownloadWorker` (WorkManager, HTTPS, MediaStore `Download/DJ Fusion Player` ou dossier SAF, progression, annulation) |

## Mixage réel
Chaque platine a son propre `ExoPlayer` ; les deux jouent simultanément et Android les mixe.
Le crossfader règle `player.volume` de chaque platine (courbe cos/sin, puissance constante).
L'EQ et le filtre sont appliqués échantillon par échantillon dans la chaîne audio (`DeckFx`).
Le pitch utilise `PlaybackParameters` (±50 %, KEY LOCK = tonalité conservée).

## Limites connues
- BPM : saisi par TAP (pas d'analyse automatique) ; les boucles automatiques en dépendent.
- Pré-écoute : nécessite un casque filaire/USB/Bluetooth ; une platine est routée vers le casque.
- Le studio DJ ne traite que l'audio.
