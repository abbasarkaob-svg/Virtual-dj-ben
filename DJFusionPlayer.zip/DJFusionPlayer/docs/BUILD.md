# Compiler DJ Fusion Player

Prérequis : Android Studio Ladybug (2024.2) ou plus récent, JDK 17, Android SDK 35.

1. Ouvrir le dossier dans Android Studio : la synchronisation Gradle démarre automatiquement.
2. Si `gradle/wrapper/gradle-wrapper.jar` est absent, exécuter une fois (Gradle 8.9 installé) :
   `gradle wrapper --gradle-version 8.9` — puis `./gradlew assembleDebug`.
3. APK : `app/build/outputs/apk/debug/app-debug.apk`.

minSdk 29 (Android 10), targetSdk 35. Permissions : INTERNET, notifications, service média.
La bibliothèque utilise le sélecteur de fichiers Android (aucune permission de stockage).
